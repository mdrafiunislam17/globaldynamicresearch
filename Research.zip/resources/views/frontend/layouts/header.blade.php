
    <header class="main-header transparent">
        <div class="container">
            <div class="navigation-wrapper">
                <div class="navigation-inner">
                    <div class="site-logo">
                        <a href="index.html"><img src="assets/img/logo-dark.png" alt="Softgen"></a>
                    </div>
                    <nav class="navigation-menu">
                        <ul class="main-menu">
                            <li><a href="index.html">Home</a>
                                <ul>
                                    <!-- <li><a href="index.html">Marketing Startup</a></li>
                                    <li><a href="index-2.html">App Promotion</a></li>
                                    <li><a href="index-3.html">Software Saas</a></li>
                                    <li><a href="index-4.html">It Solutions</a></li> -->
                                </ul>
                            </li>
                              <li><a href="#">Research Paper</a>
                                <ul>
                                    <li><a href="#">Submit Research Paper</a></li>
                                    <li><a href="#">Publication Guidelines</a></li>
                                    <li><a href="#">Services Details</a></li>
                                    <li><a href="#">Publication Charges</a></li>
                                    <li><a href="#">Upload Documents</a></li>
                                    <li><a href="#">Track Status / Pay Fees / Download Publication Certi.</a></li>
                                </ul>
                            </li>
                            <li><a href="about.html">Current Issue</a>
                                <!-- <ul>
                                    <li><a href="about.html">About Us</a></li>
                                    <li><a href="services.html">Our Services</a></li>
                                    <li><a href="service-details.html">Services Details</a></li>
                                    <li><a href="team.html">Our Team</a></li>
                                    <li><a href="team-details.html">Team Details</a></li>
                                    <li><a href="pricing.html">Plans &amp; Pricing</a></li>
                                    <li><a href="testimonial.html">Testimonials</a></li>
                                    <li><a href="faqs.html">Help &amp; FAQ's</a></li>
                                    <li><a href="404.html">404 Error</a></li>
                                </ul> -->
                            </li>
                            <li><a href="#">Publication Archive</a>
                                <!-- <ul>
                                    <li><a href="projects.html">Our Projects</a></li>
                                    <li><a href="project-details.html">Project Details</a></li>
                                </ul> -->
                            </li>
                            <li><a href="#">Editors & Reviewers</a>
                                <ul>
                                    <li><a href="#">View All</a></li>
                                    <li><a href="#">Join as a Reviewer</a></li>
                                    <li><a href="#">Get Membership Certificate</a></li>
                                </ul>
                            </li>

                              <li><a href="#">Conference</a>
                                <ul>
                                    <li><a href="#">Publishing Conf. with IJFMR</a></li>
                                    <li><a href="#">Upcoming Conference(s)</a></li>
                                    <li><a href="#">WSMCDD-2025</a></li>
                                     <li><a href="#">GSMCDD-2025</a></li>
                                      <li><a href="#">AIMAR-2025</a></li>
                                       <li><a href="#">Conferences Published</a></li>
                                        <li><a href="#">ICCE (2025)</a></li>
                                         <li><a href="#">RBS:RH-COVID-19 (2023)</a></li>
                                          <li><a href="#">ICMRS'23</a></li>
                                           <li><a href="#">PIPRDA-2023</a></li>
                                </ul>
                            </li>
                            <li><a href="#">Contact</a></li>
                        </ul>
                    </nav>
                    <!-- <div class="header-right">
                        <a href="contact.html" class="default-btn d-none d-md-block">Start Free Trial</a>
                        <button class="sidebar-trigger open">
                            <svg class="trigger-opener" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="16px" height="12.7px" viewBox="0 0 16 12.7" style="enable-background:new 0 0 16 12.7;" xml:space="preserve">
                                <g>
                                    <rect x="5" y="8.4" width="11" height="2" />
                                    <rect x="0" y="2.4" width="16" height="2" />
                                </g>
                            </svg>
                        </button>
                        <div class="mobile-menu-icon">
                            <div class="burger-menu">
                                <div class="line-menu line-half first-line"></div>
                                <div class="line-menu"></div>
                                <div class="line-menu line-half last-line"></div>
                            </div>
                        </div>
                    </div> -->
                </div>
            </div>
        </div>
    </header>
    <!--/.main-header-->
