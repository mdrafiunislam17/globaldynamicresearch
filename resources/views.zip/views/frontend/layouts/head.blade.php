 <style>
        img.lazy {
            min-height: 1px
        }
    </style>
    <link href="assets/js/wp-emoji-release.min.js" as="script">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-title" content="globaldynamiCresearch - ISRT, University of Dhaka">
    {{-- <link rel="profile" href="http://gmpg.org/xfn/11">
    <link rel="pingback" href="https://isrt.ac.bd/xmlrpc.php"> --}}
    <link rel="stylesheet" href="{{url('https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css')}}">

     @stack("styles")
    <title>globaldynamiCresearch &#8211; ISRT, University of Dhaka</title>
    <meta name='robots' content='max-image-preview:large' />
    <style>
        img:is([sizes="auto" i], [sizes^="auto," i]) {
            contain-intrinsic-size: 3000px 1500px
        }
    </style>
    <link rel="alternate" type="text/calendar" title="globaldynamiCresearch &raquo; iCal Feed" href="https://isrt.ac.bd/events/?ical=1" />
    <!-- This site uses the Google Analytics by MonsterInsights plugin v9.6.1 - Using Analytics tracking - https://www.monsterinsights.com/ -->
    <!-- Note: MonsterInsights is not currently configured on this site. The site owner needs to authenticate with Google Analytics in the MonsterInsights settings panel. -->
    <!-- No tracking code set -->
    <!-- / Google Analytics by MonsterInsights -->

    <style id='wp-emoji-styles-inline-css' type='text/css'>
        img.wp-smiley,
        img.emoji {
            display: inline !important;
            border: none !important;
            box-shadow: none !important;
            height: 1em !important;
            width: 1em !important;
            margin: 0 0.07em !important;
            vertical-align: -0.1em !important;
            background: none !important;
            padding: 0 !important;
        }
    </style>
    <link rel="stylesheet" href="assets/wp-content/cache/minify/a5ff7.css" media="all" />

    <style id='classic-theme-styles-inline-css' type='text/css'>
        /*! This file is auto-generated */

        .wp-block-button__link {
            color: #fff;
            background-color: #32373c;
            border-radius: 9999px;
            box-shadow: none;
            text-decoration: none;
            padding: calc(.667em + 2px) calc(1.333em + 2px);
            font-size: 1.125em
        }

        .wp-block-file__button {
            background: #32373c;
            color: #fff;
            text-decoration: none
        }
    </style>
    <style id='global-styles-inline-css' type='text/css'>
        :root {
            --wp--preset--aspect-ratio--square: 1;
            --wp--preset--aspect-ratio--4-3: 4/3;
            --wp--preset--aspect-ratio--3-4: 3/4;
            --wp--preset--aspect-ratio--3-2: 3/2;
            --wp--preset--aspect-ratio--2-3: 2/3;
            --wp--preset--aspect-ratio--16-9: 16/9;
            --wp--preset--aspect-ratio--9-16: 9/16;
            --wp--preset--color--black: #000000;
            --wp--preset--color--cyan-bluish-gray: #abb8c3;
            --wp--preset--color--white: #ffffff;
            --wp--preset--color--pale-pink: #f78da7;
            --wp--preset--color--vivid-red: #cf2e2e;
            --wp--preset--color--luminous-vivid-orange: #ff6900;
            --wp--preset--color--luminous-vivid-amber: #fcb900;
            --wp--preset--color--light-green-cyan: #7bdcb5;
            --wp--preset--color--vivid-green-cyan: #00d084;
            --wp--preset--color--pale-cyan-blue: #8ed1fc;
            --wp--preset--color--vivid-cyan-blue: #0693e3;
            --wp--preset--color--vivid-purple: #9b51e0;
            --wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg, rgba(6, 147, 227, 1) 0%, rgb(155, 81, 224) 100%);
            --wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg, rgb(122, 220, 180) 0%, rgb(0, 208, 130) 100%);
            --wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg, rgba(252, 185, 0, 1) 0%, rgba(255, 105, 0, 1) 100%);
            --wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg, rgba(255, 105, 0, 1) 0%, rgb(207, 46, 46) 100%);
            --wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg, rgb(238, 238, 238) 0%, rgb(169, 184, 195) 100%);
            --wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg, rgb(74, 234, 220) 0%, rgb(151, 120, 209) 20%, rgb(207, 42, 186) 40%, rgb(238, 44, 130) 60%, rgb(251, 105, 98) 80%, rgb(254, 248, 76) 100%);
            --wp--preset--gradient--blush-light-purple: linear-gradient(135deg, rgb(255, 206, 236) 0%, rgb(152, 150, 240) 100%);
            --wp--preset--gradient--blush-bordeaux: linear-gradient(135deg, rgb(254, 205, 165) 0%, rgb(254, 45, 45) 50%, rgb(107, 0, 62) 100%);
            --wp--preset--gradient--luminous-dusk: linear-gradient(135deg, rgb(255, 203, 112) 0%, rgb(199, 81, 192) 50%, rgb(65, 88, 208) 100%);
            --wp--preset--gradient--pale-ocean: linear-gradient(135deg, rgb(255, 245, 203) 0%, rgb(182, 227, 212) 50%, rgb(51, 167, 181) 100%);
            --wp--preset--gradient--electric-grass: linear-gradient(135deg, rgb(202, 248, 128) 0%, rgb(113, 206, 126) 100%);
            --wp--preset--gradient--midnight: linear-gradient(135deg, rgb(2, 3, 129) 0%, rgb(40, 116, 252) 100%);
            --wp--preset--font-size--small: 13px;
            --wp--preset--font-size--medium: 20px;
            --wp--preset--font-size--large: 36px;
            --wp--preset--font-size--x-large: 42px;
            --wp--preset--spacing--20: 0.44rem;
            --wp--preset--spacing--30: 0.67rem;
            --wp--preset--spacing--40: 1rem;
            --wp--preset--spacing--50: 1.5rem;
            --wp--preset--spacing--60: 2.25rem;
            --wp--preset--spacing--70: 3.38rem;
            --wp--preset--spacing--80: 5.06rem;
            --wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);
            --wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);
            --wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);
            --wp--preset--shadow--outlined: 6px 6px 0px -3px rgba(255, 255, 255, 1), 6px 6px rgba(0, 0, 0, 1);
            --wp--preset--shadow--crisp: 6px 6px 0px rgba(0, 0, 0, 1);
        }

        :where(.is-layout-flex) {
            gap: 0.5em;
        }

        :where(.is-layout-grid) {
            gap: 0.5em;
        }

        body .is-layout-flex {
            display: flex;
        }

        .is-layout-flex {
            flex-wrap: wrap;
            align-items: center;
        }

        .is-layout-flex> :is(*, div) {
            margin: 0;
        }

        body .is-layout-grid {
            display: grid;
        }

        .is-layout-grid> :is(*, div) {
            margin: 0;
        }

        :where(.wp-block-columns.is-layout-flex) {
            gap: 2em;
        }

        :where(.wp-block-columns.is-layout-grid) {
            gap: 2em;
        }

        :where(.wp-block-post-template.is-layout-flex) {
            gap: 1.25em;
        }

        :where(.wp-block-post-template.is-layout-grid) {
            gap: 1.25em;
        }

        .has-black-color {
            color: var(--wp--preset--color--black) !important;
        }

        .has-cyan-bluish-gray-color {
            color: var(--wp--preset--color--cyan-bluish-gray) !important;
        }

        .has-white-color {
            color: var(--wp--preset--color--white) !important;
        }

        .has-pale-pink-color {
            color: var(--wp--preset--color--pale-pink) !important;
        }

        .has-vivid-red-color {
            color: var(--wp--preset--color--vivid-red) !important;
        }

        .has-luminous-vivid-orange-color {
            color: var(--wp--preset--color--luminous-vivid-orange) !important;
        }

        .has-luminous-vivid-amber-color {
            color: var(--wp--preset--color--luminous-vivid-amber) !important;
        }

        .has-light-green-cyan-color {
            color: var(--wp--preset--color--light-green-cyan) !important;
        }

        .has-vivid-green-cyan-color {
            color: var(--wp--preset--color--vivid-green-cyan) !important;
        }

        .has-pale-cyan-blue-color {
            color: var(--wp--preset--color--pale-cyan-blue) !important;
        }

        .has-vivid-cyan-blue-color {
            color: var(--wp--preset--color--vivid-cyan-blue) !important;
        }

        .has-vivid-purple-color {
            color: var(--wp--preset--color--vivid-purple) !important;
        }

        .has-black-background-color {
            background-color: var(--wp--preset--color--black) !important;
        }

        .has-cyan-bluish-gray-background-color {
            background-color: var(--wp--preset--color--cyan-bluish-gray) !important;
        }

        .has-white-background-color {
            background-color: var(--wp--preset--color--white) !important;
        }

        .has-pale-pink-background-color {
            background-color: var(--wp--preset--color--pale-pink) !important;
        }

        .has-vivid-red-background-color {
            background-color: var(--wp--preset--color--vivid-red) !important;
        }

        .has-luminous-vivid-orange-background-color {
            background-color: var(--wp--preset--color--luminous-vivid-orange) !important;
        }

        .has-luminous-vivid-amber-background-color {
            background-color: var(--wp--preset--color--luminous-vivid-amber) !important;
        }

        .has-light-green-cyan-background-color {
            background-color: var(--wp--preset--color--light-green-cyan) !important;
        }

        .has-vivid-green-cyan-background-color {
            background-color: var(--wp--preset--color--vivid-green-cyan) !important;
        }

        .has-pale-cyan-blue-background-color {
            background-color: var(--wp--preset--color--pale-cyan-blue) !important;
        }

        .has-vivid-cyan-blue-background-color {
            background-color: var(--wp--preset--color--vivid-cyan-blue) !important;
        }

        .has-vivid-purple-background-color {
            background-color: var(--wp--preset--color--vivid-purple) !important;
        }

        .has-black-border-color {
            border-color: var(--wp--preset--color--black) !important;
        }

        .has-cyan-bluish-gray-border-color {
            border-color: var(--wp--preset--color--cyan-bluish-gray) !important;
        }

        .has-white-border-color {
            border-color: var(--wp--preset--color--white) !important;
        }

        .has-pale-pink-border-color {
            border-color: var(--wp--preset--color--pale-pink) !important;
        }

        .has-vivid-red-border-color {
            border-color: var(--wp--preset--color--vivid-red) !important;
        }

        .has-luminous-vivid-orange-border-color {
            border-color: var(--wp--preset--color--luminous-vivid-orange) !important;
        }

        .has-luminous-vivid-amber-border-color {
            border-color: var(--wp--preset--color--luminous-vivid-amber) !important;
        }

        .has-light-green-cyan-border-color {
            border-color: var(--wp--preset--color--light-green-cyan) !important;
        }

        .has-vivid-green-cyan-border-color {
            border-color: var(--wp--preset--color--vivid-green-cyan) !important;
        }

        .has-pale-cyan-blue-border-color {
            border-color: var(--wp--preset--color--pale-cyan-blue) !important;
        }

        .has-vivid-cyan-blue-border-color {
            border-color: var(--wp--preset--color--vivid-cyan-blue) !important;
        }

        .has-vivid-purple-border-color {
            border-color: var(--wp--preset--color--vivid-purple) !important;
        }

        .has-vivid-cyan-blue-to-vivid-purple-gradient-background {
            background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;
        }

        .has-light-green-cyan-to-vivid-green-cyan-gradient-background {
            background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;
        }

        .has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background {
            background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;
        }

        .has-luminous-vivid-orange-to-vivid-red-gradient-background {
            background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;
        }

        .has-very-light-gray-to-cyan-bluish-gray-gradient-background {
            background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;
        }

        .has-cool-to-warm-spectrum-gradient-background {
            background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;
        }

        .has-blush-light-purple-gradient-background {
            background: var(--wp--preset--gradient--blush-light-purple) !important;
        }

        .has-blush-bordeaux-gradient-background {
            background: var(--wp--preset--gradient--blush-bordeaux) !important;
        }

        .has-luminous-dusk-gradient-background {
            background: var(--wp--preset--gradient--luminous-dusk) !important;
        }

        .has-pale-ocean-gradient-background {
            background: var(--wp--preset--gradient--pale-ocean) !important;
        }

        .has-electric-grass-gradient-background {
            background: var(--wp--preset--gradient--electric-grass) !important;
        }

        .has-midnight-gradient-background {
            background: var(--wp--preset--gradient--midnight) !important;
        }

        .has-small-font-size {
            font-size: var(--wp--preset--font-size--small) !important;
        }

        .has-medium-font-size {
            font-size: var(--wp--preset--font-size--medium) !important;
        }

        .has-large-font-size {
            font-size: var(--wp--preset--font-size--large) !important;
        }

        .has-x-large-font-size {
            font-size: var(--wp--preset--font-size--x-large) !important;
        }

        :where(.wp-block-post-template.is-layout-flex) {
            gap: 1.25em;
        }

        :where(.wp-block-post-template.is-layout-grid) {
            gap: 1.25em;
        }

        :where(.wp-block-columns.is-layout-flex) {
            gap: 2em;
        }

        :where(.wp-block-columns.is-layout-grid) {
            gap: 2em;
        }

        :root :where(.wp-block-pullquote) {
            font-size: 1.5em;
            line-height: 1.6;
        }
    </style>
    <link rel="stylesheet" href="{{asset('assets/wp-content/cache/minify/300ec.css')}}" media="all" />

    <style id='nfd-wonder-blocks-utilities-inline-css' type='text/css'>
        .nfd-relative {
            position: relative !important
        }

        .-nfd-bottom-1 {
            bottom: -.25rem !important
        }

        .-nfd-top-0\.5 {
            top: -.125rem !important
        }

        .-nfd-top-1 {
            top: -.25rem !important
        }

        .nfd-top-10 {
            top: 2.5rem !important
        }

        .nfd-col-start-1 {
            grid-column-start: 1 !important
        }

        .nfd-col-start-2 {
            grid-column-start: 2 !important
        }

        .nfd-col-start-3 {
            grid-column-start: 3 !important
        }

        .nfd-col-start-4 {
            grid-column-start: 4 !important
        }

        .nfd-col-start-5 {
            grid-column-start: 5 !important
        }

        .nfd-col-start-6 {
            grid-column-start: 6 !important
        }

        .nfd-col-start-7 {
            grid-column-start: 7 !important
        }

        .nfd-col-end-10 {
            grid-column-end: 10 !important
        }

        .nfd-col-end-11 {
            grid-column-end: 11 !important
        }

        .nfd-col-end-12 {
            grid-column-end: 12 !important
        }

        .nfd-col-end-13 {
            grid-column-end: 13 !important
        }

        .nfd-col-end-7 {
            grid-column-end: 7 !important
        }

        .nfd-col-end-8 {
            grid-column-end: 8 !important
        }

        .nfd-col-end-9 {
            grid-column-end: 9 !important
        }

        .nfd-row-start-1 {
            grid-row-start: 1 !important
        }

        .-nfd-mx-2:not([style*=margin]) {
            margin-left: -.5rem !important;
            margin-right: -.5rem !important
        }

        .nfd-my-0:not([style*=margin]) {
            margin-bottom: 0 !important;
            margin-top: 0 !important
        }

        .nfd-mb-8:not([style*=margin]) {
            margin-bottom: 2rem !important
        }

        .nfd-mt-8:not([style*=margin]) {
            margin-top: 2rem !important
        }

        .nfd-mt-\[-100px\]:not([style*=margin]) {
            margin-top: -100px !important
        }

        .nfd-grid {
            display: grid !important
        }

        .nfd-h-full {
            height: 100% !important
        }

        .nfd-w-full {
            width: 100% !important
        }

        .nfd-shrink-0 {
            flex-shrink: 0 !important
        }

        .nfd-grow {
            flex-grow: 1 !important
        }

        .nfd-grid-cols-11 {
            grid-template-columns: repeat(11, minmax(0, 1fr)) !important
        }

        .nfd-grid-cols-12 {
            grid-template-columns: repeat(12, minmax(0, 1fr)) !important
        }

        .nfd-grid-cols-2 {
            grid-template-columns: repeat(2, minmax(0, 1fr)) !important
        }

        .nfd-grid-rows-1 {
            grid-template-rows: repeat(1, minmax(0, 1fr)) !important
        }

        .nfd-items-center {
            align-items: center !important
        }

        .nfd-gap-y-10 {
            row-gap: 2.5rem !important
        }

        .nfd-overflow-hidden {
            overflow: hidden !important
        }

        .nfd-border-b {
            border-bottom-width: 1px !important
        }

        .nfd-border-dashed {
            border-style: dashed !important
        }

        .nfd-p-0:not([style*=padding]) {
            padding: 0 !important
        }

        .nfd-p-10:not([style*=padding]) {
            padding: 2.5rem !important
        }

        .nfd-p-2:not([style*=padding]) {
            padding: .5rem !important
        }

        .nfd-p-4:not([style*=padding]) {
            padding: 1rem !important
        }

        .nfd-p-8:not([style*=padding]) {
            padding: 2rem !important
        }

        .nfd-px-0:not([style*=padding]) {
            padding-left: 0 !important;
            padding-right: 0 !important
        }

        .nfd-px-4:not([style*=padding]) {
            padding-left: 1rem !important;
            padding-right: 1rem !important
        }

        .nfd-px-8:not([style*=padding]) {
            padding-left: 2rem !important;
            padding-right: 2rem !important
        }

        .nfd-py-0:not([style*=padding]) {
            padding-bottom: 0 !important;
            padding-top: 0 !important
        }

        .nfd-py-4:not([style*=padding]) {
            padding-bottom: 1rem !important;
            padding-top: 1rem !important
        }

        .nfd-py-5:not([style*=padding]) {
            padding-bottom: 1.25rem !important;
            padding-top: 1.25rem !important
        }

        .nfd-pt-0:not([style*=padding]) {
            padding-top: 0 !important
        }

        .nfd-text-left {
            text-align: left !important
        }

        .nfd-wc-products {
            self-align: flex-start !important;
            flex-grow: 0 !important
        }

        .nfd-wc-products>ul {
            row-gap: calc(var(--wndb--gap--2xl)*var(--wndb--gap--scale-factor)) !important
        }

        .nfd-wc-products .wc-block-grid__product-image {
            overflow: hidden !important
        }

        .nfd-wc-products .wc-block-grid__product-image img {
            transition: transform .6s ease-in-out !important
        }

        .nfd-wc-products .wc-block-grid__product-image img:hover {
            transform: scale(1.1) !important
        }

        .nfd-wc-products .wc-block-components-product-sale-badge {
            -webkit-backdrop-filter: blur(4px) !important;
            backdrop-filter: blur(4px) !important;
            background: hsla(0, 0%, 100%, .5) !important;
            border: 1px solid hsla(0, 0%, 100%, .2) !important;
            border-radius: 999px !important;
            font-size: .8125rem !important;
            font-weight: 700 !important;
            margin: 6px !important;
            padding: 4px 12px !important
        }

        .nfd-wc-products .wc-block-components-product-sale-badge>span {
            background: transparent !important
        }

        .nfd-wc-products .wc-block-components-product-price {
            color: inherit !important
        }

        .nfd-wc-search .wp-block-search__inside-wrapper {
            background-color: var(--wndb--color--borders) !important;
            border: 2px solid var(--wndb--color--subtle) !important;
            border-radius: 999px !important;
            max-width: 100% !important;
            padding: 0 !important;
            width: 25rem !important
        }

        .nfd-wc-search .wp-block-search__inside-wrapper input[type=search] {
            background: none !important;
            border: none !important;
            border-bottom-left-radius: 999px !important;
            border-top-left-radius: 999px !important;
            color: var(--wndb--color--text--contrast) !important;
            font-size: 1.25rem !important;
            font-weight: 500 !important;
            min-height: 3.75rem !important;
            padding-inline: 24px !important
        }

        .nfd-wc-search .wp-block-search__inside-wrapper:has(button:focus),
        .nfd-wc-search .wp-block-search__inside-wrapper:has(input[type=search]:focus) {
            outline: 2px solid var(--wndb--color--text--contrast) !important;
            outline-offset: 2px !important
        }

        .nfd-wc-search .wp-block-search__button {
            aspect-ratio: 1/1 !important;
            background: var(--wndb-gray-800) !important;
            border-radius: 999px !important;
            height: 100% !important;
            margin-left: 0 !important;
            margin-right: 2px !important;
            margin-top: 2px !important
        }

        .nfd-wc-search .wp-block-search__button:focus,
        .nfd-wc-search .wp-block-search__button:hover {
            background: var(--wndb-gray-900) !important;
            filter: none !important;
            outline: 2px solid var(--wndb-gray-900) !important;
            outline-offset: 2px !important
        }

        .nfd-wc-search .wp-block-search__inside-wrapper input[type=search]::-moz-placeholder {
            color: var(--wndb--color--text--faded) !important
        }

        .nfd-wc-search .wp-block-search__inside-wrapper input[type=search]::placeholder {
            color: var(--wndb--color--text--faded) !important
        }

        :root {
            --wndb-mask-color: rgba(0, 0, 0, .15);
            --wndb-mask-position: 50% 50% at 50% 20%;
            --wndb-mask-opacity: 0.35
        }

        [class*=nfd-bg-effect] {
            isolation: isolate !important;
            position: relative !important
        }

        [class*=nfd-wb-header] [class*=nfd-bg-effect] {
            z-index: 1 !important
        }

        .has-modal-open [class*=nfd-bg-effect] {
            isolation: unset !important
        }

        .nfd-bg-effect-position-center {
            --wndb-mask-position: 50% 50% at 50% 50%
        }

        [class*=nfd-bg-effect]:after {
            content: "" !important;
            inset: 0 !important;
            -webkit-mask-image: radial-gradient(ellipse var(--wndb-mask-position), #000 70%, rgba(0, 0, 0, .3) 100%) !important;
            mask-image: radial-gradient(ellipse var(--wndb-mask-position), #000 70%, rgba(0, 0, 0, .3) 100%) !important;
            opacity: var(--wndb-mask-opacity) !important;
            pointer-events: none !important;
            position: absolute !important;
            z-index: -1 !important
        }

        .nfd-bg-effect-dots:after {
            --wndb-mask-opacity: 1;
            background: radial-gradient(var(--wndb-mask-color) 1px, transparent 1px) !important;
            background-size: 20px 20px !important
        }

        .nfd-bg-effect-grid:after {
            background-image: linear-gradient(to right, var(--wndb-mask-color) 1px, transparent 1px), linear-gradient(to bottom, var(--wndb-mask-color) 1px, transparent 1px) !important;
            background-size: 50px 50px !important
        }

        .nfd-bg-effect-grid-perspective {
            perspective: 1000px !important
        }

        .has-modal-open .nfd-bg-effect-grid-perspective {
            perspective: unset !important
        }

        .nfd-bg-effect-grid-perspective:after {
            --wndb-mask-opacity: 0.6;
            background-size: 100px 100px !important;
            transform: rotateX(-60deg) translateZ(0) !important;
            transform-origin: top !important;
            transform-style: preserve-3d !important
        }

        .nfd-bg-effect-grid-2:after,
        .nfd-bg-effect-grid-perspective:after {
            background-image: linear-gradient(to right, var(--wndb-mask-color) 1px, transparent 1px), linear-gradient(to bottom, var(--wndb-mask-color) 1px, transparent 1px) !important
        }

        .nfd-bg-effect-grid-2:after {
            background-size: 14px 32px !important
        }

        .nfd-bg-effect-grid-3 {
            overflow: hidden !important
        }

        .nfd-bg-effect-grid-3:after {
            background-image: linear-gradient(to right, var(--wndb-mask-color) 1px, transparent 1px), linear-gradient(to bottom, var(--wndb-mask-color) 1px, transparent 1px) !important;
            background-size: 32px 80px !important;
            right: -40% !important;
            top: -20% !important;
            transform: scale(1.5) skew(-30deg, 30deg) !important
        }

        .nfd-bg-effect-lines:after {
            --wndb-mask-opacity: 0.4;
            background-image: linear-gradient(to right, var(--wndb-mask-color) 1px, transparent 1px) !important;
            background-size: 48px !important
        }

        .nfd-bg-effect-lines-2 {
            --wndb-mask-opacity: 0.45;
            overflow: hidden !important;
            perspective: 1000px !important
        }

        .has-modal-open .nfd-bg-effect-lines-2 {
            perspective: unset !important
        }

        .nfd-bg-effect-lines-2:after {
            background-image: linear-gradient(to right, var(--wndb-mask-color) 1px, transparent 1px) !important;
            background-size: 30px !important;
            right: -40% !important;
            top: -20% !important;
            transform: rotateX(-45deg) skew(-16deg) translateZ(0) !important;
            transform-origin: right !important;
            transform-style: preserve-3d !important
        }

        .nfd-mask-opacity-0:after {
            --wndb-mask-opacity: 0.8
        }

        :where(:root) {
            --wndb--max-w--prose: min(65ch, 1100px)
        }

        .nfd-max-w-prose:not(.nfd-max-w-full),
        :where(.nfd-text-balance:not(.nfd-max-w-full)) {
            max-width: var(--wndb--max-w--prose) !important
        }

        .nfd-max-w-prose:not(.nfd-max-w-full).has-text-align-center,
        :where(.nfd-text-balance:not(.nfd-max-w-full)).has-text-align-center {
            margin-inline: auto !important
        }

        .nfd-max-w-prose:not(.nfd-max-w-full).has-text-align-right,
        :where(.nfd-text-balance:not(.nfd-max-w-full)).has-text-align-right {
            margin-inline-start: auto !important
        }

        :where(.nfd-text-balance) {
            text-wrap: balance !important
        }

        .nfd-text-balance>h1,
        .nfd-text-balance>h2,
        .nfd-text-balance>h3,
        .nfd-text-balance>h4,
        .nfd-text-balance>p {
            text-wrap: balance !important
        }

        .nfd-text-pretty,
        .nfd-text-pretty>h1,
        .nfd-text-pretty>h2,
        .nfd-text-pretty>h3,
        .nfd-text-pretty>h4,
        .nfd-text-pretty>p {
            text-wrap: pretty !important
        }

        .wp-block-image figcaption {
            font-weight: 400 !important;
            margin-inline: auto !important;
            max-width: 64ch !important;
            padding-block-start: .5em !important;
            text-wrap: balance !important
        }

        .wp-block-quote>.nfd-text-pretty {
            font-weight: 550;
            margin-block: .25em
        }

        :where(:root) {
            --wndb--text-scale-factor: 1;
            --wndb--text--xs: 0.75rem;
            --wndb--text--sm: 0.875rem;
            --wndb--text--base: 1rem;
            --wndb--text--md: 1.125rem;
            --wndb--text--lg: 1.5rem;
            --wndb--text--xl: 2.375rem;
            --wndb--text--huge: clamp(2.75rem, 1.4688rem + 2.5vw, 3.5rem);
            --wndb--text-giga: clamp(3.25rem, 2.546875rem + 2.25vw, 4.375rem)
        }

        .nfd-text-xs:not([class*=font-size]):not([style*=font-size]) {
            font-size: calc(var(--wndb--text--xs)*var(--wndb--text-scale-factor)) !important
        }

        .nfd-text-xs:not([style*=letter-spacing]) {
            letter-spacing: .05em !important
        }

        .nfd-text-sm:not([class*=font-size]):not([style*=font-size]) {
            font-size: calc(var(--wndb--text--sm)*var(--wndb--text-scale-factor)) !important
        }

        .nfd-text-base:not([class*=font-size]):not([style*=font-size]) {
            font-size: calc(var(--wndb--text--base)*var(--wndb--text-scale-factor)) !important
        }

        .nfd-text-md:not([class*=font-size]):not([style*=font-size]) {
            font-size: calc(var(--wndb--text--md)*var(--wndb--text-scale-factor)) !important
        }

        .nfd-text-base:not([style*=line-height]),
        .nfd-text-md:not([style*=line-height]) {
            line-height: 1.6 !important
        }

        .nfd-text-lg:not([class*=font-size]):not([style*=font-size]) {
            font-size: calc(var(--wndb--text--lg)*var(--wndb--text-scale-factor)) !important
        }

        .nfd-text-lg:not([style*=line-height]) {
            line-height: 1.4 !important
        }

        .nfd-text-lg:not([style*=letter-spacing]) {
            letter-spacing: 0 !important
        }

        .nfd-text-lg:not([style*=font-weight]) {
            font-weight: 500 !important
        }

        .nfd-text-xl:not([class*=font-size]):not([style*=font-size]) {
            font-size: var(--wndb--text--xl) !important
        }

        .nfd-text-xl:not([style*=line-height]) {
            line-height: 1.25 !important
        }

        .nfd-text-xl:not([style*=letter-spacing]) {
            letter-spacing: -.01em !important
        }

        .nfd-text-xl:not([style*=font-weight]) {
            font-weight: 500 !important
        }

        :where(.nfd-text-huge:not([class*=font-size]):not([style*=font-size])) {
            font-size: calc(var(--wndb--text--huge)*var(--wndb--text-scale-factor)) !important;
            max-width: var(--wndb--max-w--prose) !important;
            text-wrap: balance !important
        }

        :where(.nfd-text-giga:not([class*=font-size]):not([style*=font-size])).has-text-align-center,
        :where(.nfd-text-huge:not([class*=font-size]):not([style*=font-size])).has-text-align-center {
            margin-inline: auto !important
        }

        :where(.nfd-text-giga:not([class*=font-size]):not([style*=font-size])).has-text-align-right,
        :where(.nfd-text-huge:not([class*=font-size]):not([style*=font-size])).has-text-align-right {
            margin-inline-start: auto !important
        }

        .nfd-text-huge:not([style*=line-height]) {
            line-height: 1.1 !important
        }

        .nfd-text-huge:not([style*=letter-spacing]) {
            letter-spacing: -.025em !important
        }

        .nfd-text-huge:not([style*=font-weight]) {
            font-weight: 500 !important
        }

        :where(.nfd-text-giga:not([class*=font-size]):not([style*=font-size])) {
            font-size: calc(var(--wndb--text-giga)*var(--wndb--text-scale-factor)) !important;
            max-width: var(--wndb--max-w--prose) !important;
            text-wrap: balance !important
        }

        .nfd-text-giga:not([style*=line-height]) {
            line-height: 1.1 !important
        }

        .nfd-text-giga:not([style*=letter-spacing]) {
            letter-spacing: -.04em !important
        }

        .nfd-text-giga:not([style*=font-weight]) {
            font-weight: 500 !important
        }

        :root {
            --nfd-wb-anim-transition-duration: 1400ms;
            --nfd-wb-anim-transition-delay: 50ms;
            --nfd-wb-anim-transition-easing-function: cubic-bezier(0.4, 1, 0.65, 1);
            --nfd-wb-anim-transition: all var(--nfd-wb-anim-transition-duration) var(--nfd-wb-anim-transition-easing-function) var(--nfd-wb-anim-transition-delay)
        }

        @media (prefers-reduced-motion:reduce) {
            .nfd-wb-animate {
                transition: none !important
            }
            .nfd-wb-twist-in,
            [class*=nfd-wb-] {
                clip-path: none !important;
                opacity: 1 !important;
                transform: none !important
            }
        }

        @media (max-width:782px) {
            .nfd-wb-animate {
                transition: none !important
            }
            .nfd-wb-twist-in,
            [class*=nfd-wb-] {
                clip-path: none !important;
                opacity: 1 !important;
                transform: none !important
            }
        }

        .nfd-wb-animate[data-replay-animation] {
            transition: none !important
        }

        .block-editor-block-preview__content-iframe [class*=nfd-wb-] {
            clip-path: none !important;
            opacity: 1 !important;
            transform: none !important
        }

        [class*=nfd-wb-fade-in] {
            --nfd-wb-anim-transition: opacity var(--nfd-wb-anim-transition-duration) var(--nfd-wb-anim-transition-easing-function) var(--nfd-wb-anim-transition-delay), transform var(--nfd-wb-anim-transition-duration) var(--nfd-wb-anim-transition-easing-function) var(--nfd-wb-anim-transition-delay);
            transition: var(--nfd-wb-anim-transition)
        }

        .nfd-wb-fade-in-bottom {
            --nfd-wb-anim-transition-duration: 1200ms;
            opacity: 0;
            transform: translate3d(0, 90px, 0);
            transition: var(--nfd-wb-anim-transition)
        }

        .nfd-wb-fade-in-bottom-short {
            transform: translate3d(0, 32px, 0) scale3d(.96, .96, .96);
            transform-origin: center bottom
        }

        .nfd-wb-fade-in-bottom-short,
        .nfd-wb-fade-in-top-short {
            --nfd-wb-anim-transition-duration: 600ms;
            opacity: 0;
            transition: var(--nfd-wb-anim-transition)
        }

        .nfd-wb-fade-in-top-short {
            transform: translate3d(0, -32px, 0) scale3d(.96, .96, .96);
            transform-origin: center top
        }

        .nfd-wb-fade-in-left-short {
            transform: translate3d(-32px, 0, 0) scale3d(.96, .96, .96);
            transform-origin: center left
        }

        .nfd-wb-fade-in-left-short,
        .nfd-wb-fade-in-right-short {
            --nfd-wb-anim-transition-duration: 600ms;
            opacity: 0;
            transition: var(--nfd-wb-anim-transition)
        }

        .nfd-wb-fade-in-right-short {
            transform: translate3d(32px, 0, 0) scale3d(.96, .96, .96);
            transform-origin: right center
        }

        .nfd-wb-animated-in:not([data-replay-animation])[class*=nfd-wb-fade-in] {
            opacity: 1;
            transform: translateZ(0) scaleX(1)
        }

        .nfd-wb-zoom-in {
            --nfd-wb-anim-transition-duration: 1200ms;
            --nfd-wb-anim-transition: opacity var(--nfd-wb-anim-transition-duration) var(--nfd-wb-anim-transition-easing-function) var(--nfd-wb-anim-transition-delay), transform var(--nfd-wb-anim-transition-duration) var(--nfd-wb-anim-transition-easing-function) var(--nfd-wb-anim-transition-delay);
            transform: scale3d(.4, .4, .4)
        }

        .nfd-wb-zoom-in,
        .nfd-wb-zoom-in-short {
            opacity: 0;
            transition: var(--nfd-wb-anim-transition)
        }

        .nfd-wb-zoom-in-short {
            --nfd-wb-anim-transition-duration: 600ms;
            --nfd-wb-anim-transition: opacity var(--nfd-wb-anim-transition-duration) var(--nfd-wb-anim-transition-easing-function) var(--nfd-wb-anim-transition-delay), transform var(--nfd-wb-anim-transition-duration) var(--nfd-wb-anim-transition-easing-function) var(--nfd-wb-anim-transition-delay);
            transform: scale3d(.92, .92, .92)
        }

        .nfd-wb-animated-in:not([data-replay-animation])[class*=nfd-wb-zoom-] {
            opacity: 1 !important;
            transform: scaleX(1) !important
        }

        div:has(>.nfd-wb-twist-in) {
            perspective: 1200px
        }

        .nfd-wb-twist-in {
            --nfd-wb-anim-transition-duration: 1000ms;
            --nfd-wb-anim-transition: opacity var(--nfd-wb-anim-transition-duration) var(--nfd-wb-anim-transition-easing-function) var(--nfd-wb-anim-transition-delay), transform var(--nfd-wb-anim-transition-duration) var(--nfd-wb-anim-transition-easing-function) var(--nfd-wb-anim-transition-delay);
            opacity: 0;
            transform: translateY(40px) scale(.8) rotateY(30deg) rotate(-12deg) translateZ(0);
            transition: var(--nfd-wb-anim-transition)
        }

        .nfd-wb-animated-in:not([data-replay-animation]).nfd-wb-twist-in {
            opacity: 1 !important;
            transform: translateY(0) scale(1) rotateY(0deg) rotate(0deg) translateZ(0) !important
        }

        .nfd-wb-reveal-right {
            --nfd-wb-anim-transition-duration: 1500ms;
            --nfd-wb-anim-transition-easing-function: cubic-bezier(0.4, 0, 0, 1);
            --nfd-wb-anim-transition: clip-path var(--nfd-wb-anim-transition-duration) var(--nfd-wb-anim-transition-easing-function) var(--nfd-wb-anim-transition-delay);
            clip-path: inset(0 100% 0 0);
            transition: var(--nfd-wb-anim-transition)
        }

        .nfd-wb-animated-in>.nfd-wb-reveal-right:not([data-replay-animation]) {
            clip-path: inset(0 0 0 0) !important
        }

        .nfd-delay-50 {
            --nfd-wb-anim-transition-delay: 50ms
        }

        .nfd-delay-150 {
            --nfd-wb-anim-transition-delay: 150ms
        }

        .nfd-delay-300 {
            --nfd-wb-anim-transition-delay: 300ms
        }

        .nfd-delay-450 {
            --nfd-wb-anim-transition-delay: 450ms
        }

        .nfd-delay-600 {
            --nfd-wb-anim-transition-delay: 600ms
        }

        .nfd-delay-750 {
            --nfd-wb-anim-transition-delay: 750ms
        }

        .nfd-delay-900 {
            --nfd-wb-anim-transition-delay: 900ms
        }

        .nfd-delay-1050 {
            --nfd-wb-anim-transition-delay: 1050ms
        }

        .nfd-delay-1200 {
            --nfd-wb-anim-transition-delay: 1200ms
        }

        .nfd-delay-1350 {
            --nfd-wb-anim-transition-delay: 1350ms
        }

        .nfd-delay-1500 {
            --nfd-wb-anim-transition-delay: 1500ms
        }

        :where(:root) {
            --wndb--container: 1200px;
            --wndb--container--wide: 1340px
        }

        body .is-layout-constrained:has(.nfd-container.is-layout-constrained)>.nfd-container.is-layout-constrained {
            max-width: unset !important;
            width: 100% !important
        }

        .is-layout-constrained.has-global-padding:has(.nfd-container.is-layout-constrained)>.nfd-container.is-layout-constrained {
            margin-left: calc(var(--wp--style--root--padding-left)*-1) !important;
            margin-right: calc(var(--wp--style--root--padding-right)*-1) !important;
            max-width: unset !important;
            width: unset !important
        }

        .editor-styles-wrapper .nfd-container:is(.is-layout-constrained)>:where(:not(.alignleft):not(.alignright):not(.alignfull):not(.alignwide)),
        .editor-styles-wrapper .nfd-container>:where(.wp-block-cover-is-layout-constrained:not(.alignleft):not(.alignright):not(.alignfull):not(.alignwide)):not([style*=margin]),
        .nfd-container:is(.is-layout-constrained)>:where(:not(.alignleft):not(.alignright):not(.alignfull):not(.alignwide)),
        .nfd-container:is(.nfd-my-0)>div,
        .nfd-container>:where(.wp-block-cover-is-layout-constrained:not(.alignleft):not(.alignright):not(.alignfull):not(.alignwide)) {
            max-width: var(--wndb--container);
            width: 100%
        }

        .editor-styles-wrapper .nfd-container:is(.is-layout-constrained)>.alignwide,
        .nfd-container:is(.is-layout-constrained).alignwide>:where(:not(.alignleft):not(.alignright):not(.alignfull)):not([style*=margin]),
        .nfd-container:is(.is-layout-constrained)>.alignwide,
        .nfd-container:is(.nfd-my-0)>.alignwide {
            max-width: var(--wndb--container--wide);
            width: 100%
        }

        .nfd-container:not(.alignfull) {
            padding-inline: var(--wndb--p) !important
        }

        .nfd-container:is(.nfd-my-0)>div:not([style*=margin]) {
            margin-inline: auto !important
        }

        [class*=nfd-divider-] {
            position: relative;
            z-index: 13
        }

        [class*=nfd-divider-]~[class*=nfd-divider-] {
            z-index: 12 !important
        }

        [class*=nfd-divider-]~[class*=nfd-divider-]~[class*=nfd-divider-] {
            z-index: 11 !important
        }

        [class*=nfd-divider-]:before {
            background: inherit !important;
            bottom: calc(var(--wndb--divider-size)*-1) !important;
            content: "" !important;
            height: var(--wndb--divider-size) !important;
            left: 0 !important;
            pointer-events: none !important;
            position: absolute !important;
            width: 100% !important;
            z-index: 10 !important
        }

        .nfd-divider-arrow {
            --wndb--divider-size: 16px
        }

        .nfd-divider-arrow:before {
            bottom: calc(var(--wndb--divider-size)*-1) !important;
            height: calc(var(--wndb--divider-size)*2) !important;
            left: 50% !important;
            transform: translateX(-50%) rotate(45deg) !important;
            width: calc(var(--wndb--divider-size)*2) !important
        }

        .nfd-divider-clouds {
            --wndb--divider-size: 150px
        }

        .nfd-divider-clouds:after,
        .nfd-divider-clouds:before {
            background: inherit !important;
            background-image: url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' preserveAspectRatio='xMidYMax slice' viewBox='0 0 283.5 27.8'%3E%3Cpath fill='%23fff' d='M0 0v6.7c1.9-.8 4.7-1.4 8.5-1 9.5 1.1 11.1 6 11.1 6s2.1-.7 4.3-.2c2.1.5 2.8 2.6 2.8 2.6s.2-.5 1.4-.7 1.7.2 1.7.2 0-2.1 1.9-2.8 3.6.7 3.6.7.7-2.9 3.1-4.1 4.7 0 4.7 0 1.2-.5 2.4 0 1.7 1.4 1.7 1.4h1.4c.7 0 1.2.7 1.2.7s.8-1.8 4-2.2c3.5-.4 5.3 2.4 6.2 4.4q.6-.6 1.8-.9c2.8-.7 4 .7 4 .7s1.7-5 11.1-6c9.5-1.1 12.3 3.9 12.3 3.9s1.2-4.8 5.7-5.7 6.8 1.8 6.8 1.8.6-.6 1.5-.9c.9-.2 1.9-.2 1.9-.2s5.2-6.4 12.6-3.3c7.3 3.1 4.7 9 4.7 9s1.9-.9 4 0 2.8 2.4 2.8 2.4 1.9-1.2 4.5-1.2 4.3 1.2 4.3 1.2.2-1 1.4-1.7 2.1-.7 2.1-.7-.5-3.1 2.1-5.5 5.7-1.4 5.7-1.4 1.5-2.3 4.2-1.1 1.7 5.2 1.7 5.2.3-.1 1.3.5c.5.4.8.8.9 1.1.5-1.4 2.4-5.8 8.4-4 7.1 2.1 3.5 8.9 3.5 8.9s.8-.4 2 0 1.1 1.1 1.1 1.1 1.1-1.1 2.3-1.1 2.1.5 2.1.5 1.9-3.6 6.2-1.2 1.9 6.4 1.9 6.4 2.6-2.4 7.4 0c3.4 1.7 3.9 4.9 3.9 4.9s3.3-6.9 10.4-7.9 11.5 2.6 11.5 2.6.8 0 1.2.2.9.9.9.9 4.4-3.1 8.3.2c1.9 1.7 1.5 5 1.5 5s.3-1.1 1.6-1.4 2.3.2 2.3.2-.1-1.2.5-1.9 1.9-.9 1.9-.9-4.7-9.3 4.4-13.4c5.6-2.5 9.2.9 9.2.9s5-6.2 15.9-6.2 16.1 8.1 16.1 8.1.7-.2 1.6-.4V0z'/%3E%3C/svg%3E") !important;
            background-repeat: repeat-x !important;
            background-size: cover !important;
            content: "" !important;
            height: var(--wndb--divider-size) !important;
            left: 0 !important;
            pointer-events: none !important;
            position: absolute !important;
            top: 0 !important;
            width: 100% !important;
            z-index: 10 !important
        }

        .nfd-divider-clouds:after {
            bottom: 0 !important;
            top: auto !important;
            transform: rotate(180deg) !important
        }

        .nfd-divider-ellipse {
            --wndb--divider-size: 50px
        }

        .nfd-divider-ellipse:before {
            clip-path: ellipse(50% var(--wndb--divider-size) at 50% 0) !important
        }

        .nfd-divider-rounded:not([style*=-radius]) {
            --wndb--divider-size: 50px
        }

        .nfd-divider-rounded:before:not([style*=-radius]) {
            border-bottom-left-radius: var(--wndb--divider-size) !important;
            border-bottom-right-radius: var(--wndb--divider-size) !important
        }

        .nfd-divider-slant,
        .nfd-divider-slant-invert {
            --wndb--divider-size: 80px
        }

        .nfd-divider-slant:before {
            bottom: calc(var(--wndb--divider-size)*-1 + 1px) !important;
            clip-path: polygon(0 0, 100% 0, 0 100%) !important
        }

        .nfd-divider-slant-invert:before {
            bottom: calc(var(--wndb--divider-size)*-1 + 1px) !important;
            clip-path: polygon(0 0, 100% 0, 100% 100%) !important
        }

        .nfd-divider-triangle {
            --wndb--divider-size: 80px
        }

        .nfd-divider-triangle:before {
            bottom: calc(var(--wndb--divider-size)*-1 + 1px) !important;
            clip-path: polygon(0 0, 100% 0, 50% 100%) !important
        }

        .nfd-divider-zigzag {
            --wndb--divider-size: 8px
        }

        .nfd-divider-zigzag:before {
            -webkit-mask: conic-gradient(from -45deg at bottom, #0000, #000 1deg 89deg, #0000 90deg) 50% /calc(var(--wndb--divider-size)*2) 100% !important;
            mask: conic-gradient(from -45deg at bottom, #0000, #000 1deg 89deg, #0000 90deg) 50% /calc(var(--wndb--divider-size)*2) 100% !important
        }

        :where(:root) {
            --wndb--divider-size: 0px
        }

        .nfd-grid-cols-1-2-1 {
            grid-template-columns: 1fr 2fr 1fr !important
        }

        :where(:root) {
            --wndb--padding-factor: 1;
            --wndb--p: 2.375rem;
            --wndb--p--xs: 0.75rem;
            --wndb--p--sm: 1.5rem;
            --wndb--p--md: 2rem;
            --wndb--p--lg: clamp(3.5rem, 7vw, 6.25rem);
            --wndb--p--square: 2.5rem;
            --wndb--p--square-lg: 4rem
        }

        .nfd-p-card-sm:not([style*=padding]) {
            padding: calc(var(--wndb--p--xs)*var(--wndb--padding-factor)) calc(var(--wndb--p--sm)*var(--wndb--padding-factor)) !important
        }

        .nfd-p-card-md:not([style*=padding]) {
            padding: calc(var(--wndb--p--sm)*var(--wndb--padding-factor)) calc(var(--wndb--p--md)*var(--wndb--padding-factor)) !important
        }

        .nfd-p-card-lg:not([style*=padding]) {
            padding: calc(var(--wndb--p--md)*var(--wndb--padding-factor)) calc(var(--wndb--p--md)*var(--wndb--padding-factor)) !important
        }

        @media screen and (min-width:782px) {
            .nfd-p-card-lg:not([style*=padding]) {
                padding: calc(var(--wndb--p--md)*var(--wndb--padding-factor)) calc(var(--wndb--p--md)*1.5*var(--wndb--padding-factor)) !important
            }
        }

        .nfd-p-card-square-lg:not([style*=padding]),
        .nfd-p-card-square:not([style*=padding]) {
            padding: calc(var(--wndb--p--square)*var(--wndb--padding-factor)) !important
        }

        @media screen and (min-width:782px) {
            .nfd-p-card-square-lg:not([style*=padding]) {
                padding: calc(var(--wndb--p--square-lg)*var(--wndb--padding-factor)) !important
            }
        }

        .nfd-p-xs:not([style*=padding]) {
            padding: calc(var(--wndb--p--xs)*var(--wndb--padding-factor)) !important
        }

        .nfd-py-xs:not([style*=padding]) {
            padding-block: calc(var(--wndb--p--xs)*var(--wndb--padding-factor)) !important
        }

        .nfd-pt-xs:not([style*=padding]) {
            padding-block-start: calc(var(--wndb--p--xs)*var(--wndb--padding-factor)) !important
        }

        .nfd-px-xs:not([style*=padding]) {
            padding-inline: calc(var(--wndb--p--xs)*var(--wndb--padding-factor)) !important
        }

        .nfd-p-sm:not([style*=padding]) {
            padding: calc(var(--wndb--p--sm)*var(--wndb--padding-factor)) !important
        }

        .nfd-px-sm:not([style*=padding]) {
            padding-inline: calc(var(--wndb--p--sm)*var(--wndb--padding-factor)) !important
        }

        .nfd-py-sm:not([style*=padding]) {
            padding-block: calc(var(--wndb--p--sm)*var(--wndb--padding-factor)) !important
        }

        .nfd-pt-sm:not([style*=padding]) {
            padding-block-start: calc(var(--wndb--p--sm)*var(--wndb--padding-factor)) !important
        }

        .nfd-pb-sm:not([style*=padding]) {
            padding-block-end: calc(var(--wndb--p--sm)*var(--wndb--padding-factor)) !important
        }

        .nfd-pl-sm:not([style*=padding]) {
            padding-left: calc(var(--wndb--p--sm)*var(--wndb--padding-factor)) !important
        }

        .nfd-p-md:not([style*=padding]) {
            padding: calc(var(--wndb--p--md)*var(--wndb--padding-factor)) !important
        }

        .nfd-px-md:not([style*=padding]) {
            padding-inline: calc(var(--wndb--p--md)*var(--wndb--padding-factor)) !important
        }

        .nfd-pb-md:not([style*=padding]),
        .nfd-pt-md:not([style*=padding]),
        .nfd-py-md:not([style*=padding]) {
            padding-block: calc(var(--wndb--p--md)*var(--wndb--padding-factor)) !important
        }

        .nfd-p-lg:not([style*=padding]) {
            padding: calc(var(--wndb--p--lg)*var(--wndb--padding-factor)) calc(var(--wndb--p--md)*var(--wndb--padding-factor)) !important
        }

        .nfd-py-lg:not([style*=padding]) {
            padding-block: calc(var(--wndb--p--lg)*var(--wndb--padding-factor)) !important
        }

        .nfd-pt-lg:not([style*=padding]) {
            padding-block-start: calc(var(--wndb--p--lg)*var(--wndb--padding-factor)) !important
        }

        .nfd-pb-lg:not([style*=padding]) {
            padding-block-end: calc(var(--wndb--p--lg)*var(--wndb--padding-factor)) !important
        }

        .nfd-pl-offset-md:not([style*=padding]) {
            margin-left: calc(var(--wndb--p--md)*var(--wndb--padding-factor)*-1) !important;
            padding-left: calc(var(--wndb--p--md)*var(--wndb--padding-factor) - 3px) !important
        }

        .editor-styles-wrapper .nfd-overlap-x,
        .nfd-overlap-x {
            gap: 0
        }

        .nfd-overlap-x>:not(:first-child) {
            margin-inline-start: -1.275rem !important
        }

        @media (min-width:768px) {
            .-nfd-translate-y-1\/2 {
                transform: translateY(-50%) !important
            }
        }

        .nfd-pseudo-play-icon {
            align-items: center !important;
            display: flex !important;
            justify-content: center !important;
            position: relative !important
        }

        .nfd-pseudo-play-icon>a {
            inset: 0 !important;
            position: absolute !important
        }

        :not(.is-root-container) .nfd-pseudo-play-icon>a {
            text-indent: -9999px !important
        }

        .nfd-pseudo-play-icon:before {
            -webkit-backdrop-filter: blur(3px) !important;
            backdrop-filter: blur(3px) !important;
            background: hsla(0, 0%, 100%, .1) !important;
            border-radius: 100% !important;
            content: "" !important;
            height: 3rem !important;
            left: 50% !important;
            opacity: 1 !important;
            pointer-events: none !important;
            position: absolute !important;
            top: 50% !important;
            transform: translate(-50%, -50%) !important;
            transition: all .2s ease !important;
            width: 3rem !important
        }

        .nfd-pseudo-play-icon:has(a:hover):before {
            background: hsla(0, 0%, 100%, .3) !important;
            height: 4rem !important;
            width: 4rem !important
        }

        .nfd-pseudo-play-icon:after {
            border-style: solid !important;
            border-bottom: 10px solid transparent !important;
            border-left: 16px solid !important;
            border-right: 0 !important;
            border-top: 10px solid transparent !important;
            content: "" !important;
            height: 16px !important;
            height: 0 !important;
            left: 50% !important;
            margin-left: 2px !important;
            pointer-events: none !important;
            position: absolute !important;
            top: 50% !important;
            transform: translate(-50%, -50%) !important;
            width: 16px !important;
            width: 0 !important
        }

        .entry-content>.wp-block-group.has-background+.wp-block-group.has-background:not([style*=margin-top]),
        .entry-content>.wp-block-group.has-background+[class*=nfd-theme-]:not([style*=margin-top]),
        .entry-content>[class*=nfd-theme-]+.wp-block-group.has-background:not([style*=margin-top]),
        .entry-content>[class*=nfd-theme-]+[class*=nfd-theme-]:not([style*=margin-top]) {
            margin-block-start: 0 !important
        }

        :where(:root) {
            --wndb--gap--scale-factor: 1;
            --wndb--gap--xs: 0.25rem;
            --wndb--gap--sm: 0.5rem;
            --wndb--gap--md: 1rem;
            --wndb--gap--lg: 1.5rem;
            --wndb--gap--xl: 2rem;
            --wndb--gap--2xl: 2.5rem;
            --wndb--gap--3xl: 3.5rem;
            --wndb--gap--4xl: 6rem
        }

        .editor-styles-wrapper .nfd-gap-0,
        .nfd-gap-0 {
            gap: 0
        }

        .editor-styles-wrapper .nfd-gap-xs,
        .nfd-gap-xs {
            gap: calc(var(--wndb--gap--xs)*var(--wndb--gap--scale-factor))
        }

        .editor-styles-wrapper .nfd-gap-sm,
        .nfd-gap-sm {
            gap: calc(var(--wndb--gap--sm)*var(--wndb--gap--scale-factor))
        }

        .editor-styles-wrapper .nfd-gap-md,
        .nfd-gap-md {
            gap: calc(var(--wndb--gap--md)*var(--wndb--gap--scale-factor))
        }

        .editor-styles-wrapper .nfd-gap-lg,
        .nfd-gap-lg {
            gap: calc(var(--wndb--gap--lg)*var(--wndb--gap--scale-factor))
        }

        .editor-styles-wrapper .nfd-gap-xl,
        .nfd-gap-xl {
            gap: calc(var(--wndb--gap--xl)*var(--wndb--gap--scale-factor))
        }

        .editor-styles-wrapper .nfd-gap-2xl,
        .nfd-gap-2xl {
            gap: calc(var(--wndb--gap--2xl)*var(--wndb--gap--scale-factor))
        }

        .editor-styles-wrapper .nfd-gap-3xl,
        .nfd-gap-3xl {
            gap: calc(var(--wndb--gap--3xl)*var(--wndb--gap--scale-factor))
        }

        .editor-styles-wrapper .nfd-gap-4xl,
        .nfd-gap-4xl {
            gap: calc(var(--wndb--gap--4xl)*var(--wndb--gap--scale-factor))
        }

        .editor-styles-wrapper .nfd-gap-x-4xl,
        .nfd-gap-x-4xl {
            -moz-column-gap: calc(var(--wndb--gap--4xl)*var(--wndb--gap--scale-factor));
            column-gap: calc(var(--wndb--gap--4xl)*var(--wndb--gap--scale-factor))
        }

        .editor-styles-wrapper .nfd-gap-x-lg,
        .nfd-gap-x-lg {
            -moz-column-gap: calc(var(--wndb--gap--lg)*var(--wndb--gap--scale-factor));
            column-gap: calc(var(--wndb--gap--lg)*var(--wndb--gap--scale-factor))
        }

        .editor-styles-wrapper .nfd-gap-y-lg,
        .nfd-gap-y-lg {
            row-gap: calc(var(--wndb--gap--lg)*var(--wndb--gap--scale-factor))
        }

        .editor-styles-wrapper .nfd-gap-y-xl,
        .nfd-gap-y-xl {
            row-gap: calc(var(--wndb--gap--xl)*var(--wndb--gap--scale-factor))
        }

        .editor-styles-wrapper .nfd-gap-y-2xl,
        .nfd-gap-y-2xl {
            row-gap: calc(var(--wndb--gap--2xl)*var(--wndb--gap--scale-factor))
        }

        .editor-styles-wrapper .nfd-gap-y-3xl,
        .nfd-gap-y-3xl {
            row-gap: calc(var(--wndb--gap--3xl)*var(--wndb--gap--scale-factor))
        }

        .nfd-border-2 {
            border-bottom-width: 2px !important
        }

        .nfd-border-strong {
            border-color: var(--wndb-color--borders-strong) !important
        }

        :where(:root) {
            --wndb--button--outline-width: 0px;
            --wndb--button-sm--font-size: 1rem;
            --wndb--button-lg-x: 2rem;
            --wndb--button-lg-y: 0.75rem;
            --wndb--button-lg--font-size: 1.125rem;
            --wndb--button-xl-x: 3rem;
            --wndb--button-xl-y: 1rem;
            --wndb--button-xl--font-size: 1.125rem
        }

        [class*=nfd-btn].is-style-outline {
            --wndb--button--outline-width: 2px
        }

        [class*=nfd-btn]>.wp-block-button__link:not([style*=padding]) {
            padding: calc(.625rem - var(--wndb--button--outline-width)) calc(1.125rem - var(--wndb--button--outline-width)) !important
        }

        .nfd-btn-sm>.wp-block-button__link:not([style*=padding]) {
            padding: calc(.375rem - var(--wndb--button--outline-width)) calc(1rem - var(--wndb--button--outline-width)) !important
        }

        .nfd-btn-sm:not(.has-custom-font-size)>.wp-block-button__link:not([style*=font-size]) {
            font-size: var(--wndb--button-sm--font-size) !important
        }

        .nfd-btn-lg>.wp-block-button__link:not([style*=padding]) {
            padding: calc(var(--wndb--button-lg-y) - var(--wndb--button--outline-width)) var(--wndb--button-lg-x) !important
        }

        .nfd-btn-lg:not(.has-custom-font-size)>.wp-block-button__link:not([style*=font-size]) {
            font-size: var(--wndb--button-lg--font-size) !important
        }

        .nfd-btn-lg:not([style*=font-weight])>.wp-block-button__link {
            font-weight: 600 !important
        }

        .nfd-btn-xl>.wp-block-button__link:not([style*=padding]) {
            padding: calc(var(--wndb--button-xl-y) - var(--wndb--button--outline-width)) var(--wndb--button-xl-x) !important
        }

        .nfd-btn-xl:not(.has-custom-font-size)>.wp-block-button__link:not([style*=font-size]) {
            font-size: var(--wndb--button-xl--font-size) !important
        }

        .nfd-btn-xl:not([style*=font-weight])>.wp-block-button__link {
            font-weight: 600 !important
        }

        .nfd-btn-wide>.wp-block-button__link:not([style*=padding]) {
            padding: calc(.625rem - var(--wndb--button--outline-width)) calc(2rem - var(--wndb--button--outline-width)) !important
        }

        [class*=nfd-btn]:is(.is-style-outline)>.wp-block-button__link:not(.has-text-color) {
            color: var(--wndb--color--text--contrast) !important
        }

        .nfd-btn:is(.is-style-outline)>.wp-block-button__link:not(.has-text-color):hover {
            --wndb--color--text--contrast: var(--wndb-gray-900);
            border-color: var(--wndb-white) !important
        }

        [class*=nfd-button]>.wp-block-button__link:not(.has-background):hover {
            filter: brightness(.8) !important
        }

        .nfd-theme-primary [class*=nfd-btn]:not(.is-style-outline):not(.nfd-btn-secondary):not(.nfd-btn-tertiary)>.wp-block-button__link:not(.has-background) {
            background-color: var(--wndb-gray-800) !important
        }

        .nfd-theme-primary [class*=nfd-btn]:not(.is-style-outline):not(.nfd-btn-secondary):not(.nfd-btn-tertiary)>.wp-block-button__link:not(.has-background):hover {
            background-color: var(--wndb-gray-900) !important
        }

        .nfd-theme-primary [class*=nfd-btn]:is(.is-style-outline):not(.nfd-btn-secondary):not(.nfd-btn-tertiary)>.wp-block-button__link:not(.has-background):not(.has-text-color):hover {
            background-color: var(--wndb-white) !important;
            border-color: var(--wndb-white) !important;
            color: var(--wndb-gray-900) !important
        }

        .nfd-btn-secondary:is(.is-style-outline)>.wp-block-button__link:not(.has-text-color):hover {
            --wndb--color--text--contrast: var(--wndb-gray-900);
            border-color: var(--wndb-white) !important
        }

        .nfd-btn-secondary:not(.is-style-outline)>.wp-block-button__link:not(.has-text-color) {
            color: var(--wndb-white) !important
        }

        .nfd-btn-secondary:not(.is-style-outline)>.wp-block-button__link:not(.has-background) {
            background-color: var(--wndb-gray-800) !important
        }

        .nfd-btn-secondary:not(.is-style-outline)>.wp-block-button__link:not(.has-background):hover {
            background-color: var(--wndb-gray-900) !important
        }

        .nfd-theme-dark .nfd-btn-secondary:not(.is-style-outline)>.wp-block-button__link:not(.has-background),
        .nfd-theme-darker .nfd-btn-secondary:not(.is-style-outline)>.wp-block-button__link:not(.has-background) {
            background-color: var(--wndb-white) !important
        }

        .nfd-theme-dark .nfd-btn-secondary:not(.is-style-outline)>.wp-block-button__link:not(.has-text-color),
        .nfd-theme-darker .nfd-btn-secondary:not(.is-style-outline)>.wp-block-button__link:not(.has-text-color) {
            color: var(--wndb-gray-900) !important
        }

        .nfd-theme-dark .nfd-btn-secondary:not(.is-style-outline)>.wp-block-button__link:not(.has-background):hover,
        .nfd-theme-darker .nfd-btn-secondary:not(.is-style-outline)>.wp-block-button__link:not(.has-background):hover {
            background-color: var(--wndb-white) !important;
            color: var(--wndb-gray-900) !important;
            filter: brightness(.8) !important
        }

        .nfd-btn-tertiary:is(.is-style-outline)>.wp-block-button__link:not(.has-text-color):hover {
            --wndb--color--text--contrast: var(--wndb-gray-900)
        }

        .nfd-btn-tertiary:is(.is-style-outline)>.wp-block-button__link:not([class*=-border-color]) {
            border-color: var(--wndb--color--subtle) !important
        }

        .nfd-btn-tertiary:not(.is-style-outline)>.wp-block-button__link:not(.has-text-color) {
            color: var(--wndb--color--text--contrast) !important
        }

        .nfd-btn-tertiary:not(.is-style-outline)>.wp-block-button__link:not(.has-background) {
            background-color: var(--wndb--color--borders) !important
        }

        .nfd-btn-tertiary:not(.is-style-outline)>.wp-block-button__link:not(.has-background):hover {
            --wndb--color--borders: var(--wndb--color--subtle)
        }

        :where(:root) {
            --wndb--shadow--xs: 0 1px 2px 0 rgba(18, 18, 23, .065);
            --wndb--shadow--sm: 0 1px 3px 0 rgba(18, 18, 23, .1), 0 1px 2px 0 rgba(18, 18, 23, .06)
        }

        .nfd-shadow-xs:not([style*=box-shadow]) {
            box-shadow: var(--wndb--shadow--xs) !important
        }

        .nfd-shadow-sm:not([style*=box-shadow]) {
            box-shadow: var(--wndb--shadow--sm) !important
        }

        .nfd-bg-subtle.nfd-shadow-xs:not([style*=box-shadow]),
        .nfd-theme-light .nfd-shadow-xs:not([style*=box-shadow]) {
            --wndb--shadow--xs: none
        }

        :where(:root) {
            --wndb--rounded--scale-factor: 1;
            --wndb--border--radius--sm: 0.25rem;
            --wndb--border--radius--md: 0.5rem;
            --wndb--border--radius--lg: 0.75rem;
            --wndb--border--radius--xl: 1rem
        }

        [class*=nfd-rounded]:not([style*=-radius]),
        [class*=nfd-rounded]:not([style*=-radius])>.components-resizable-box__container>img:not([style*=-radius]),
        [class*=nfd-rounded]:not([style*=-radius])>.wp-element-button:not([style*=-radius]),
        [class*=nfd-rounded]:not([style*=-radius])>a>img,
        [class*=nfd-rounded]:not([style*=-radius])>img {
            border-radius: calc(var(--wndb--border--radius)*var(--wndb--rounded--scale-factor)) !important
        }

        [class*=nfd-rounded-t-]:not([style*=-radius]),
        [class*=nfd-rounded-t-]:not([style*=-radius])>.components-resizable-box__container>img:not([style*=-radius]),
        [class*=nfd-rounded-t-]:not([style*=-radius])>.wp-element-button:not([style*=-radius]),
        [class*=nfd-rounded-t-]:not([style*=-radius])>a>img,
        [class*=nfd-rounded-t-]:not([style*=-radius])>img {
            border-radius: calc(var(--wndb--border--radius)*var(--wndb--rounded--scale-factor)) calc(var(--wndb--border--radius)*var(--wndb--rounded--scale-factor)) 0 0 !important
        }

        .nfd-overflow-hidden.nfd-rounded-xl iframe:not([style*=-radius]) {
            border-radius: calc(var(--wndb--border--radius--md)*var(--wndb--rounded--scale-factor)) !important
        }

        .nfd-rounded-none:not([style*=-radius]) {
            --wndb--border--radius: 0
        }

        .nfd-rounded-sm:not([style*=-radius]) {
            --wndb--border--radius: var(--wndb--border--radius--sm)
        }

        .nfd-rounded,
        .nfd-rounded-md,
        .nfd-rounded-t-md:not([style*=-radius]) {
            --wndb--border--radius: var(--wndb--border--radius--md)
        }

        .nfd-rounded-lg,
        .nfd-rounded-t-lg:not([style*=-radius]) {
            --wndb--border--radius: var(--wndb--border--radius--lg)
        }

        .nfd-rounded-t-xl:not([style*=-radius]),
        .nfd-rounded-xl {
            --wndb--border--radius: var(--wndb--border--radius--xl)
        }

        .nfd-rounded-full:not([style*=-radius]) {
            --wndb--border--radius: 9999px
        }

        :where(:root) {
            --wndb-gray: #6c6c89;
            --wndb-gray-50: #f7f7f8;
            --wndb-gray-100: #ebebef;
            --wndb-gray-150: #e5e5e9;
            --wndb-gray-200: #d1d1db;
            --wndb-gray-300: #a9a9bc;
            --wndb-gray-400: #8a8aa3;
            --wndb-gray-500: #6c6c89;
            --wndb-gray-600: #55556d;
            --wndb-gray-700: #3f3f50;
            --wndb-gray-800: #1d1d22;
            --wndb-gray-900: #121217;
            --wndb-white: #fff;
            --wndb-white-50: hsla(0, 0%, 100%, .05);
            --wndb-white-100: hsla(0, 0%, 100%, .1);
            --wndb-white-150: hsla(0, 0%, 100%, .15);
            --wndb-white-200: hsla(0, 0%, 100%, .2);
            --wndb-white-300: hsla(0, 0%, 100%, .3);
            --wndb-white-400: hsla(0, 0%, 100%, .4);
            --wndb-white-500: hsla(0, 0%, 100%, .5);
            --wndb-white-600: hsla(0, 0%, 100%, .6);
            --wndb-white-700: hsla(0, 0%, 100%, .7);
            --wndb-white-800: hsla(0, 0%, 100%, .8);
            --wndb-white-900: hsla(0, 0%, 100%, .9);
            --wndb--color--primary: #00f;
            --wndb--color--secondary: #00f;
            --wndb--color--surface: var(--wndb-gray-50);
            --wndb--color--text: var(--wndb-gray-800);
            --wndb--color--text--contrast: var(--wndb-gray-900);
            --wndb--color--text--faded: var(--wndb-gray-600);
            --wndb--color--borders: var(--wndb-gray-150);
            --wndb--color--borders-light: var(--wndb-gray-100);
            --wndb--color--borders-strong: var(--wndb--color--text--faded);
            --wndb--color--subtle: var(--wndb-gray-200);
            --wndb--color--links: var(--wndb--color--primary);
            --wndb--color--body: var(--wndb--color--surface)
        }

        .is-style-nfd-theme-white,
        .nfd-theme-white:not([class*=is-style-nfd-theme]) {
            --wndb--color--borders: var(--wndb-gray-150);
            --wndb--color--borders-light: var(--wndb-gray-100);
            --wndb--color--links: var(--wndb--color--primary);
            --wndb--color--subtle: var(--wndb-gray-200);
            --wndb--color--surface: var(--wndb-white);
            --wndb--color--text--contrast: var(--wndb-gray-900);
            --wndb--color--text--faded: var(--wndb-gray-700);
            --wndb--color--text: var(--wndb-gray-800)
        }

        .is-style-nfd-theme-light,
        .nfd-theme-light:not([class*=is-style-nfd-theme]) {
            --wndb--color--borders: var(--wndb-gray-150);
            --wndb--color--borders-light: var(--wndb-gray-150);
            --wndb--color--links: var(--wndb--color--primary);
            --wndb--color--subtle: var(--wndb-gray-200);
            --wndb--color--surface: var(--wndb-gray-50);
            --wndb--color--text--contrast: var(--wndb-gray-900);
            --wndb--color--text--faded: var(--wndb-gray-700);
            --wndb--color--text: var(--wndb-gray-800)
        }

        .is-style-nfd-theme-dark,
        .nfd-theme-dark:not([class*=is-style-nfd-theme]) {
            --wndb--color--borders: var(--wndb-white-100);
            --wndb--color--borders-light: var(--wndb--color--borders);
            --wndb--color--subtle: var(--wndb-white-200);
            --wndb--color--surface: var(--wndb-gray-800);
            --wndb--color--text--contrast: var(--wndb-white);
            --wndb--color--text--faded: var(--wndb-white-800);
            --wndb--color--text: var(--wndb-white);
            --wndb--shadow--sm: none;
            --wndb--shadow--xs: none;
            --wndb-mask-color: hsla(0, 0%, 100%, .12)
        }

        .is-style-nfd-theme-darker,
        .nfd-theme-darker:not([class*=is-style-nfd-theme]) {
            --wndb--color--borders: var(--wndb-white-100);
            --wndb--color--borders-light: var(--wndb--color--borders);
            --wndb--color--subtle: var(--wndb-white-200);
            --wndb--color--surface: var(--wndb-gray-900);
            --wndb--color--text--contrast: var(--wndb-white);
            --wndb--color--text--faded: var(--wndb-white-800);
            --wndb--color--text: var(--wndb-white);
            --wndb--shadow--sm: none;
            --wndb--shadow--xs: none;
            --wndb-mask-color: hsla(0, 0%, 100%, .12)
        }

        .is-style-nfd-theme-primary,
        .nfd-theme-primary:not([class*=is-style-nfd-theme]) {
            --wndb--color--borders: var(--wndb-white-100);
            --wndb--color--borders-light: var(--wndb--color--borders);
            --wndb--color--subtle: var(--wndb-white-200);
            --wndb--color--surface: var(--wndb--color--primary);
            --wndb--color--text--contrast: var(--wndb-white);
            --wndb--color--text--faded: var(--wndb-white-900);
            --wndb--color--text: var(--wndb-white);
            --wndb--shadow--sm: none;
            --wndb--shadow--xs: none;
            --wndb-mask-color: hsla(0, 0%, 100%, .12)
        }

        .nfd-bg-surface:not(.has-background),
        [class*=is-style-nfd-theme]:not(.has-background) {
            background-color: var(--wndb--color--surface) !important
        }

        .nfd-bg-surface:not(.has-text-color),
        [class*=is-style-nfd-theme]:not(.has-text-color) {
            color: var(--wndb--color--text) !important
        }

        .nfd-text-faded p:not(.has-text-color):not(.has-link-color):not(.has-background):not(.nfd-text-primary),
        .nfd-text-faded time:not(.has-text-color):not(.has-background),
        .nfd-text-faded>a:not(.has-text-color):not(.has-link-color):not(.has-background),
        ol.nfd-text-faded:not(.has-text-color):not(.has-link-color):not(.has-background):not(.nfd-text-primary),
        p.nfd-text-faded:not(.has-text-color):not(.has-link-color):not(.has-background),
        ul.nfd-text-faded:not(.has-text-color):not(.has-link-color):not(.has-background):not(.nfd-text-primary) {
            color: var(--wndb--color--text--faded) !important
        }

        .editor-styles-wrapper div .nfd-text-contrast:where(:not(.has-text-color)),
        .editor-styles-wrapper div :where(.nfd-text-contrast:not(.has-text-color):not(.wp-element-button)) a:where(:not(:hover)),
        .wp-site-blocks .nfd-text-contrast:where(:not(.has-text-color)),
        .wp-site-blocks .nfd-text-contrast:where(:not(.has-text-color)) a:where(:not(:hover)) {
            color: var(--wndb--color--text--contrast)
        }

        .nfd-bg-surface [style*=border]:not([class*=border-color]):not([style*=border-top-color]):not([style*=border-right-color]):not([style*=border-bottom-color]):not([style*=border-left-color]):not(.nfd-border-strong),
        .nfd-bg-surface [style*=border]:not([class*=border-color]):not([style*=border-top-color]):not([style*=border-right-color]):not([style*=border-bottom-color]):not([style*=border-left-color])>img:not(.has-border-color):not([class*=border-color]):not([style*=border-top-color]):not([style*=border-right-color]):not([style*=border-bottom-color]):not([style*=border-left-color]),
        .nfd-bg-surface [style*=border]:not([class*=border-color]):not([style*=border-top-color]):not([style*=border-right-color]):not([style*=border-bottom-color]):not([style*=border-left-color])>img:not(.has-border-color):not([class*=border-color]):not([style*=border-top-color]):not([style*=border-right-color]):not([style*=border-bottom-color]):not([style*=border-left-color])>.components-resizable-box__container>img:not([class*=border-color]):not([style*=border-top-color]):not([style*=border-right-color]):not([style*=border-bottom-color]):not([style*=border-left-color]),
        .nfd-bg-surface:not([class*=border-color]):not([style*=border-top-color]):not([style*=border-right-color]):not([style*=border-bottom-color]):not([style*=border-left-color]):not(.has-border-color):not(.nfd-border-strong),
        [class*=is-style-nfd-theme] [style*=border]:not([class*=border-color]):not([style*=border-top-color]):not([style*=border-right-color]):not([style*=border-bottom-color]):not([style*=border-left-color]):not(.nfd-border-strong),
        [class*=is-style-nfd-theme] [style*=border]:not([class*=border-color]):not([style*=border-top-color]):not([style*=border-right-color]):not([style*=border-bottom-color]):not([style*=border-left-color])>img:not(.has-border-color):not([class*=border-color]):not([style*=border-top-color]):not([style*=border-right-color]):not([style*=border-bottom-color]):not([style*=border-left-color]),
        [class*=is-style-nfd-theme] [style*=border]:not([class*=border-color]):not([style*=border-top-color]):not([style*=border-right-color]):not([style*=border-bottom-color]):not([style*=border-left-color])>img:not(.has-border-color):not([class*=border-color]):not([style*=border-top-color]):not([style*=border-right-color]):not([style*=border-bottom-color]):not([style*=border-left-color])>.components-resizable-box__container>img:not([class*=border-color]):not([style*=border-top-color]):not([style*=border-right-color]):not([style*=border-bottom-color]):not([style*=border-left-color]),
        [class*=is-style-nfd-theme]:not([class*=border-color]):not([style*=border-top-color]):not([style*=border-right-color]):not([style*=border-bottom-color]):not([style*=border-left-color]):not(.has-border-color):not(.nfd-border-strong) {
            border-color: var(--wndb--color--borders) !important
        }

        [class*=is-style-nfd-theme] .wp-block-separator:not(.has-background):not(.has-text-color):not(.nfd-border-strong) .nfd-bg-surface .wp-block-separator:not(.has-background):not(.has-text-color):not(.nfd-border-strong) {
            border-bottom-color: var(--wndb--color--borders) !important
        }

        .nfd-bg-surface .wp-block-separator:not(.has-background):not(.has-text-color):not(.nfd-border-2),
        [class*=is-style-nfd-theme] .wp-block-separator:not(.has-background):not(.has-text-color):not(.nfd-border-2) {
            border-width: 2px 0 0 !important
        }

        .nfd-border-bg {
            --wndb--color--borders: var(--wndb--color--surface)
        }

        .nfd-border-primary {
            --wndb--color--borders: var(--wndb--color--primary)
        }

        .nfd-border-inherit {
            --wndb--color--borders: inherit
        }

        .nfd-bg-accent:not(.has-background),
        .nfd-bg-primary:not(.has-background),
        .wp-block-cover.nfd-bg-accent>.wp-block-cover__background:not([class*=background-color]),
        .wp-block-cover.nfd-bg-primary>.wp-block-cover__background:not([class*=background-color]) {
            background-color: var(--wndb--color--primary) !important
        }

        .nfd-bg-accent:not(.has-text-color),
        .nfd-bg-primary:not(.has-text-color) {
            color: var(--wndb--color--white) !important
        }

        .nfd-bg-subtle:not(.has-background):not(.wp-block-button),
        .nfd-bg-subtle:not(.has-background)>.wp-block-button__link:not(.has-background) {
            background-color: var(--wndb--color--borders-light) !important;
            color: var(--wndb--color--text--contrast) !important
        }

        .nfd-text-primary:not(.has-text-color),
        .wp-block-button.wndb-text-primary>a:not(.has-text-color) {
            color: var(--wndb--color--primary) !important
        }

        .nfd-text-secondary:not(.has-text-color),
        .wp-block-button.wndb-text-secondary>a:not(.has-text-color) {
            color: var(--wndb--color--secondary) !important
        }

        [class*=nfd-theme-primary] .nfd-text-primary:not(.has-text-color),
        [class*=nfd-theme-primary] .nfd-text-secondary:not(.has-text-color),
        [class*=nfd-theme-primary] .wp-block-button.wndb-text-primary>a:not(.has-text-color),
        [class*=nfd-theme-secondary] .wp-block-button.wndb-text-secondary>a:not(.has-text-color) {
            color: var(--wndb--color--contrast) !important
        }

        [class*=nfd-theme-dark] .nfd-text-primary:not(.has-text-color),
        [class*=nfd-theme-darker] .nfd-text-primary:not(.has-text-color) {
            color: var(--wndb--color--secondary) !important
        }

        .nfd-text-subtle:not(.has-text-color) {
            color: var(--wndb--color--subtle) !important
        }

        .editor-styles-wrapper div .nfd-text-current:where(:not(.has-text-color)),
        .editor-styles-wrapper div :where(.nfd-text-current:not(.has-text-color):not(.wp-element-button)) a:where(:not(:hover)),
        .wp-site-blocks .nfd-text-current:where(:not(.has-text-color)),
        .wp-site-blocks .nfd-text-current:where(:not(.has-text-color)) a:where(:not(:hover)) {
            color: currentColor
        }

        [class*=nfd-theme-] .wp-block-social-links.is-style-logos-only:not(.has-icon-color) .wp-block-social-link {
            color: var(--wndb--color--text--faded) !important;
            fill: var(--wndb--color--text--faded) !important
        }

        [class*=nfd-theme-] .wp-block-social-links.is-style-logos-only:not(.has-icon-color) .wp-block-social-link:hover {
            color: var(--wndb--color--text) !important;
            fill: var(--wndb--color--text) !important
        }

        .nfd-container.is-position-sticky:not([class*=nfd-bg-surface]):not([class*=is-style-nfd-]):not(.has-background) {
            background-color: var(--wndb--color--body) !important
        }

        .nfd-container .has-secondary-color {
            color: var(--wndb--color--secondary) !important
        }

        .nfd-bg-gray-100:not(.has-background),
        .nfd-bg-gray-800:not(.has-background) {
            background-color: var(--wndb--color--surface) !important
        }

        .nfd-bg-gray-100:not(.has-text-color),
        .nfd-bg-gray-800:not(.has-text-color) {
            color: var(--wndb--color--text) !important
        }

        .nfd-bg-gray-800 {
            --wndb--color--surface: var(--wndb-gray-800);
            --wndb--color--text: var(--wndb-white);
            --wndb--color--borders: var(--wndb-white-100);
            --wndb--color--text--faded: var(--wndb-white-700)
        }

        .nfd-bg-gray-100 {
            --wndb--color--surface: var(--wndb-gray-50);
            --wndb--color--text: var(--wndb-gray-700);
            --wndb--color--borders: var(--wndb-gray-100)
        }

        .nfd-text-opacity-80 p:not(.has-text-color):not(.has-link-color):not(.has-background),
        .nfd-text-opacity-80 time:not(.has-text-color):not(.has-background),
        p.nfd-text-opacity-80:not(.has-text-color):not(.has-link-color):not(.has-background) {
            opacity: .8 !important
        }

        :where(:root) {
            --wndb--slider-height: 100lvh
        }

        .nfd-scroll-slider-horizontal,
        .nfd-scroll-slider-vertical {
            flex-wrap: nowrap !important;
            height: var(--wndb--slider-height) !important;
            overflow-y: auto !important;
            scroll-snap-type: y mandatory !important;
            -ms-overflow-style: none !important;
            scrollbar-width: none !important
        }

        .nfd-scroll-slider-horizontal::-webkit-scrollbar,
        .nfd-scroll-slider-vertical::-webkit-scrollbar {
            display: none !important
        }

        .nfd-scroll-slider-vertical {
            height: 100vh !important;
            overflow-y: auto !important;
            scroll-snap-type: y mandatory !important
        }

        .nfd-scroll-slider-vertical>* {
            scroll-snap-align: start !important;
            width: 100% !important
        }

        .nfd-scroll-slider-horizontal {
            flex-direction: row !important;
            overflow-x: auto !important;
            scroll-snap-type: x mandatory !important
        }

        .nfd-scroll-slider-horizontal>* {
            flex-shrink: 0 !important;
            scroll-snap-align: start !important
        }

        .nfd-scroll-slider-horizontal>.wp-block-cover {
            width: 100vw !important
        }

        .nfd-container.alignfull .nfd-scroll-slider-horizontal {
            --half-container: calc(50vw - var(--wndb--container)/2);
            padding-left: var(--half-container) !important;
            padding-right: var(--half-container) !important;
            scroll-padding: var(--half-container) !important
        }

        .nfd-scroll-slider-horizontal.nfd-scroll-slider-animate>.wp-block-cover:first-child {
            animation: scroll-slider-slide 1s ease 1s forwards
        }

        @keyframes scroll-slider-slide {
            0% {
                margin-left: 0
            }
            to {
                margin-left: -100vw
            }
        }

        .block-editor-block-preview__content-iframe .is-root-container {
            min-height: 8rem !important
        }

        .block-editor-block-preview__content-iframe figure:has([style*="aspect-ratio: 16 / 9"]) {
            width: 100% !important
        }

        .block-editor-block-preview__content-iframe [style*="min-height: 100vh"],
        .block-editor-block-preview__content-iframe [style*="min-height:100vh"] {
            min-height: 800px !important
        }

        .block-editor-block-preview__content-iframe [style*="min-height: 70vh"],
        .block-editor-block-preview__content-iframe [style*="min-height:70vh"] {
            min-height: 560px !important
        }

        .block-editor-block-preview__content-iframe [style*="min-height: 60vh"],
        .block-editor-block-preview__content-iframe [style*="min-height:60vh"] {
            min-height: 480px !important
        }

        .block-editor-block-preview__content-iframe [style*="min-height: 50vh"],
        .block-editor-block-preview__content-iframe [style*="min-height:50vh"] {
            min-height: 400px !important
        }

        .block-editor-block-preview__content-iframe [style*="min-height: 40vh"],
        .block-editor-block-preview__content-iframe [style*="min-height:40vh"] {
            min-height: 320px !important
        }

        .block-editor-block-preview__content-iframe [style*="min-height: 35vh"],
        .block-editor-block-preview__content-iframe [style*="min-height:35vh"] {
            min-height: 280px !important
        }

        .block-editor-block-preview__content-iframe [style*="min-height: 30vh"],
        .block-editor-block-preview__content-iframe [style*="min-height:30vh"] {
            min-height: 240px !important
        }

        .block-editor-block-preview__content-iframe [style*="min-height: 10vh"],
        .block-editor-block-preview__content-iframe [style*="min-height:10vh"] {
            min-height: 80px !important
        }

        .block-editor-block-preview__content-iframe [style*="min-height: 5vh"],
        .block-editor-block-preview__content-iframe [style*="min-height:5vh"] {
            min-height: 40px !important
        }

        .nfd-wba-modal * {
            box-sizing: border-box !important
        }

        .block-editor-block-preview__content-iframe .nfd-wb-animate {
            opacity: 1 !important;
            transform: none !important;
            transition: none !important
        }

        .block-editor-block-preview__content-iframe .block-editor-warning:not(.wp-block-missing .block-editor-warning) {
            display: none !important
        }

        .block-editor-block-preview__content-iframe .is-root-container>.nfd-container:not([class*=nfd-p-]):not([class*=nfd-py-]):not([class*=nfd-pt-]):not([class*=nfd-pb-]):not([style*=padding]) {
            padding-block: var(--wndb--p) !important
        }

        .block-editor-block-preview__content-iframe [class*=nfd-rounded]:not([style*=-radius])>div>img:not([style*=-radius]) {
            border-radius: calc(var(--wndb--border--radius)*var(--wndb--rounded--scale-factor)) !important
        }

        ol.nfd-gap-sm:not(.is-layout-flex) li:not(:last-child),
        ul.nfd-gap-sm:not(.is-layout-flex) li:not(:last-child) {
            margin-bottom: .5em !important
        }

        ol.nfd-gap-md:not(.is-layout-flex) li:not(:last-child),
        ul.nfd-gap-md:not(.is-layout-flex) li:not(:last-child) {
            margin-bottom: 1em !important
        }

        ul.nfd-list-check {
            list-style-type: none !important;
            padding-inline-start: 1em !important
        }

        ul.nfd-list-check li:before {
            content: "✓";
            display: inline-block;
            margin-inline-end: 8px
        }

        [class*=nfd-query-loop-] :where(.wp-block-post-author__avatar img) {
            border-radius: 999px;
            display: block
        }

        [class*=nfd-query-loop-] :where(.avatar-48) {
            height: 36px !important;
            width: 36px !important
        }

        [class*=nfd-query-loop-] :where(.wp-block-post-author__content) {
            display: flex;
            flex-direction: column;
            gap: 4px;
            justify-content: center
        }

        [class*=nfd-query-loop-] .wp-block-post-author__avatar {
            margin-right: 12px !important
        }

        .nfd-query-loop-1 :where(.wp-block-cover) {
            aspect-ratio: 2/1.1
        }

        .nfd-query-loop-1 :where(.wp-block-post-author__content) {
            align-items: center !important;
            flex-direction: row !important
        }

        .nfd-query-loop-1 :where(.wp-block-post-author__byline) {
            font-size: 1em !important;
            opacity: .8 !important
        }

        [class*=nfd-query-loop-] :where(.wp-block-categories) {
            display: flex;
            gap: 8px;
            list-style: none;
            padding: 0
        }

        [class*=nfd-query-loop-] :where(.wp-block-categories a) {
            color: inherit !important
        }

        .nfd-query-loop-2 .wp-block-cover__background {
            -webkit-mask-image: linear-gradient(180deg, transparent 25%, #000 75%) !important;
            mask-image: linear-gradient(180deg, transparent 25%, #000 75%) !important
        }

        .nfd-query-loop-3 :where(.wp-block-post-author__name) {
            display: none !important
        }

        .nfd-form-items-grow>div:not(.wp-block-jetpack-button) {
            flex-grow: 1 !important
        }

        .nfd-jp-form.nfd-text-center .consent {
            text-align: center !important
        }

        .nfd-jp-form .contact-form-submission .go-back-message .link {
            color: currentColor !important;
            text-decoration: underline !important
        }

        .nfd-jp-form .contact-form-submission .go-back-message {
            margin-top: 0 !important
        }

        .nfd-jp-form .contact-form-submission {
            border-color: currentColor !important;
            padding: calc(var(--wndb--p--md)*.5) 0 !important
        }

        .nfd-jp-form textarea {
            resize: vertical !important
        }

        .nfd-jp-form .wp-block-button__link {
            padding-block-end: 10px !important;
            padding-block-start: 10px !important
        }

        .nfd-jp-form .consent,
        .nfd-jp-form .jetpack-field-checkbox .jetpack-field-label .jetpack-field-label__input,
        .nfd-jp-form .jetpack-field-consent .jetpack-field-label .jetpack-field-label__input {
            font-size: .875rem !important;
            line-height: 1.5em !important;
            text-transform: none !important;
            text-wrap: balance !important
        }

        .nfd-jp-form input[type=checkbox] {
            padding: 0 !important
        }

        .nfd-mask-fade-to-b>.wp-block-cover__background {
            -webkit-mask-image: linear-gradient(180deg, transparent 50%, #000 120%) !important;
            mask-image: linear-gradient(180deg, transparent 50%, #000 120%) !important
        }

        .nfd-mask-radial-center>.wp-block-cover__background {
            -webkit-mask-image: radial-gradient(circle, transparent -40%, rgba(0, 0, 0, .9) 58%) !important;
            mask-image: radial-gradient(circle, transparent -40%, rgba(0, 0, 0, .9) 58%) !important
        }

        p[style*=text-decoration]>a {
            color: inherit !important;
            text-decoration: inherit !important
        }

        .is-style-dots.nfd-text-left:before {
            padding-left: 0 !important
        }

        .nfd-h-full,
        .nfd-h-full>.components-resizable-box__container>img,
        .nfd-h-full>img {
            height: 100% !important
        }

        .nfd-w-full,
        .nfd-w-full>.components-resizable-box__container>img,
        .nfd-w-full>img {
            width: 100% !important
        }

        .nfd-backdrop-blur-sm {
            -webkit-backdrop-filter: blur(4px) !important;
            backdrop-filter: blur(4px) !important
        }

        .nfd-backdrop-blur-md {
            -webkit-backdrop-filter: blur(8px) !important;
            backdrop-filter: blur(8px) !important
        }

        :not(.editor-styles-wrapper) header:has(.nfd-absolute-header) {
            position: sticky !important;
            top: 0 !important;
            z-index: 1 !important
        }

        .nfd-absolute-header:not([style*=margin]) {
            margin: 0 !important
        }

        :not(.editor-styles-wrapper) .nfd-absolute-header:not([style*=padding]):not([class*=nfd-px-]):not([style*=padding]) {
            padding-inline: var(--wndb--p) !important
        }

        :is([style*="min-height:100vh"]) {
            min-height: calc(100vh - var(--wp-admin--admin-bar--height)) !important
        }

        @supports (height:100dvh) {
            :is([style*="height:100vh"]) {
                min-height: calc(100dvh - var(--wp-admin--admin-bar--height, 0px)) !important
            }
        }

        .nfd-wk-search .wp-block-search__input {
            font-size: inherit !important;
            min-height: 50px !important;
            padding: 8px 16px !important
        }

        :where(.wp-block-search__input) {
            border-radius: var(--wndb--border--radius--sm) !important
        }

        .nfd-stretch-cover-child,
        .nfd-stretch-cover-child .wp-block-cover__inner-container {
            display: flex !important;
            flex-direction: column !important
        }

        .nfd-stretch-cover-child .wp-block-cover__inner-container,
        .nfd-stretch-cover-child .wp-block-cover__inner-container>.nfd-pseudo-play-icon,
        .nfd-stretch-cover-child .wp-block-cover__inner-container>.wp-block-group {
            align-items: inherit !important;
            flex-grow: 1 !important;
            justify-content: inherit !important
        }

        .nfd-stretch-cover-child .wp-block-cover__inner-container>.wp-block-group,
        .nfd-stretch-cover-child .wp-block-cover__inner-container>p {
            width: 100% !important
        }

        .nfd-container summary {
            line-height: 1.5 !important;
            padding-right: 32px !important;
            position: relative !important
        }

        .nfd-container summary::marker {
            content: none !important
        }

        .nfd-container summary:before {
            align-items: center !important;
            background-color: var(--wndb--color--borders) !important;
            background-image: url("data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNCIgaGVpZ2h0PSIyNCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSJjdXJyZW50Q29sb3IiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgc3Ryb2tlLXdpZHRoPSIyIiBjbGFzcz0ibHVjaWRlIGx1Y2lkZS1wbHVzIiB2aWV3Qm94PSIwIDAgMjQgMjQiPjxwYXRoIGQ9Ik01IDEyaDE0TTEyIDV2MTQiLz48L3N2Zz4=") !important;
            background-position: 50% !important;
            background-repeat: no-repeat !important;
            background-size: 13px !important;
            border-radius: 999px !important;
            content: "" !important;
            display: flex !important;
            height: 1em !important;
            justify-content: center !important;
            opacity: .6 !important;
            position: absolute !important;
            right: 0 !important;
            top: 50% !important;
            transform: translateY(-50%) !important;
            width: 1em !important
        }

        .nfd-container [open] summary {
            font-weight: 700 !important
        }

        .nfd-container [open] summary:before {
            opacity: 1 !important;
            transform: translateY(-50%) rotate(45deg) !important
        }

        .nfd-container summary:hover:before {
            opacity: 1 !important
        }

        .is-style-wide.wp-block-separator {
            width: 100% !important
        }

        .nfd-aspect-video {
            aspect-ratio: 16/9 !important
        }

        .nfd-img-object-left img {
            -o-object-position: left !important;
            object-position: left !important
        }

        .nfd-img-object-right img {
            -o-object-position: right !important;
            object-position: right !important
        }

        .editor-styles-wrapper .wp-block-image.nfd-h-full>div {
            aspect-ratio: unset !important;
            height: 100% !important;
            max-height: unset !important
        }

        @media (max-width:782px) {
            .md\:nfd-order-2 {
                order: 2 !important
            }
            .md\:nfd-my-0:not([style*=margin]) {
                margin-bottom: 0 !important;
                margin-top: 0 !important
            }
            .md\:nfd-flex {
                display: flex !important
            }
            .md\:nfd-hidden {
                display: none !important
            }
            .md\:nfd-basis-full {
                flex-basis: 100% !important
            }
            .md\:nfd-grid-cols-1 {
                grid-template-columns: repeat(1, minmax(0, 1fr)) !important
            }
            .md\:nfd-flex-col {
                flex-direction: column !important
            }
            .md\:nfd-flex-wrap {
                flex-wrap: wrap !important
            }
            .md\:nfd-items-start {
                align-items: flex-start !important
            }
            .md\:nfd-justify-start {
                justify-content: flex-start !important
            }
            .md\:nfd-justify-end {
                justify-content: flex-end !important
            }
            .md\:nfd-justify-center {
                justify-content: center !important
            }
            .md\:nfd-gap-0 {
                gap: 0 !important
            }
            .md\:nfd-gap-4 {
                gap: 1rem !important
            }
            .md\:nfd-gap-5 {
                gap: 1.25rem !important
            }
            .md\:nfd-gap-8 {
                gap: 2rem !important
            }
            .md\:nfd-self-start {
                align-self: flex-start !important
            }
            .md\:nfd-rounded-lg:not([style*=-radius]) {
                border-radius: .5rem !important
            }
            .md\:nfd-border-none {
                border-style: none !important
            }
            .md\:nfd-p-0:not([style*=padding]) {
                padding: 0 !important
            }
            .md\:nfd-p-4:not([style*=padding]) {
                padding: 1rem !important
            }
            .md\:nfd-px-0:not([style*=padding]) {
                padding-left: 0 !important;
                padding-right: 0 !important
            }
            .md\:nfd-py-0:not([style*=padding]) {
                padding-bottom: 0 !important;
                padding-top: 0 !important
            }
            .md\:nfd-text-left {
                text-align: left !important
            }
            .md\:nfd-text-center {
                text-align: center !important
            }
        }
    </style>
    <link rel="stylesheet" href="assets/cache/minify/859e9.css" media="all" />

    <style id='akismet-widget-style-inline-css' type='text/css'>
        .a-stats {
            --akismet-color-mid-green: #357b49;
            --akismet-color-white: #fff;
            --akismet-color-light-grey: #f6f7f7;
            max-width: 350px;
            width: auto;
        }

        .a-stats * {
            all: unset;
            box-sizing: border-box;
        }

        .a-stats strong {
            font-weight: 600;
        }

        .a-stats a.a-stats__link,
        .a-stats a.a-stats__link:visited,
        .a-stats a.a-stats__link:active {
            background: var(--akismet-color-mid-green);
            border: none;
            box-shadow: none;
            border-radius: 8px;
            color: var(--akismet-color-white);
            cursor: pointer;
            display: block;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen-Sans', 'Ubuntu', 'Cantarell', 'Helvetica Neue', sans-serif;
            font-weight: 500;
            padding: 12px;
            text-align: center;
            text-decoration: none;
            transition: all 0.2s ease;
        }

        /* Extra specificity to deal with TwentyTwentyOne focus style */

        .widget .a-stats a.a-stats__link:focus {
            background: var(--akismet-color-mid-green);
            color: var(--akismet-color-white);
            text-decoration: none;
        }

        .a-stats a.a-stats__link:hover {
            filter: brightness(110%);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.06), 0 0 2px rgba(0, 0, 0, 0.16);
        }

        .a-stats .count {
            color: var(--akismet-color-white);
            display: block;
            font-size: 1.5em;
            line-height: 1.4;
            padding: 0 13px;
            white-space: nowrap;
        }
    </style>
    <script type="text/javascript" id="nfd-wonder-blocks-utilities-js-after">
        /* <![CDATA[ */
        (() => {
            var l = class {
                constructor({
                    clientId: t,
                    ...n
                } = {}) {
                    this.options = {
                        activeClass: "nfd-wb-animated-in",
                        root: null,
                        rootMargin: "0px",
                        threshold: 0,
                        ...n
                    }
                }
                observeElements(t, n = null, e = !1) {
                    if (!("IntersectionObserver" in window) || !t ? .length || document.documentElement.classList.contains("block-editor-block-preview__content-iframe")) return;

                    function a(r, i) {
                        this._mutationCallback(r, i, n)
                    }
                    let o = new IntersectionObserver(this._handleIntersection.bind(this), this.options),
                        d = new MutationObserver(a.bind(this)),
                        u = new MutationObserver(this._handleClassMutation.bind(this));
                    t.forEach(r => {
                        let i = r;
                        r.classList.contains("nfd-wb-reveal-right") && (i = r.parentElement), o.observe(i), e && (u.observe(i, {
                            attributes: !0,
                            attributeFilter: ["class"]
                        }), d.observe(i, {
                            attributes: !0,
                            attributeFilter: ["class"]
                        }))
                    })
                }
                _handleIntersection(t, n) {
                    t.forEach(e => {
                        e.isIntersecting && (e.target.classList.add(this.options.activeClass), e.target.querySelectorAll(".nfd-wb-animate").forEach(a => {
                            a.classList.add(this.options.activeClass)
                        }), n.unobserve(e.target))
                    })
                }
                _handleClassMutation(t) {
                    t.forEach(n => {
                        if (n ? .type === "attributes") {
                            let e = n.target;
                            e.classList.contains("nfd-wb-animated-in") || e.classList.add("nfd-wb-animated-in")
                        }
                    })
                }
                _mutationCallback(t, n, e = null) {
                    t.forEach(a => {
                        if (a ? .type === "attributes") {
                            let o = a.target;
                            e && e === o.getAttribute("data-block") && (o.getAttribute("data-replay-animation") === null && (o.setAttribute("data-replay-animation", !0), requestAnimationFrame(() => {
                                o.removeAttribute("data-replay-animation")
                            })), n.disconnect())
                        }
                    })
                }
            };
            document.addEventListener("DOMContentLoaded", () => {
                c()
            });
            document.addEventListener("wonder-blocks/toolbar-button-added", () => {
                c()
            });
            document.addEventListener("wonder-blocks/animation-changed", s => {
                let t = s ? .detail ? .clientId;
                c(t)
            });
            document.addEventListener("wonder-blocks/block-order-changed", () => {
                c()
            });
            window.onload = function() {
                c()
            };

            function c(s = null) {
                let t = document.body ? .classList.contains("block-editor-page") || !!s || document.body ? .classList.contains("block-editor-iframe__body"),
                    n = t ? document.querySelector(".interface-interface-skeleton__content") : null,
                    e = new l({
                        root: n,
                        threshold: 0
                    });
                requestAnimationFrame(() => {
                    let a = Array.from(document.getElementsByClassName("nfd-wb-animate"));
                    e.observeElements(a, s, t)
                })
            }
        })();
        /* ]]> */
    </script>
    <script src="assets/cache/minify/818c0.js"></script>


    <link  href="{{asset('assets/json/wp-json.json')}}" />
    <link rel="alternate" title="JSON" type="application/json" href="https://isrt.ac.bd/wp-json/wp/v2/pages/22" />

    <link rel="alternate" title="oEmbed (JSON)" type="application/json+oembed" href="https://isrt.ac.bd/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fisrt.ac.bd%2F" />
    <link rel="alternate" title="oEmbed (XML)" type="text/xml+oembed" href="https://isrt.ac.bd/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fisrt.ac.bd%2F&#038;format=xml" />
    <!-- HFCM by 99 Robots - Snippet # 1: Top marquee -->
    <div class="custom-marquee">
        <div class="marquee-content">
            <a href="#" style="color: red;">
      <b>Applications for the MS in Applied Statistics and Data Science program are now open; the deadline is July 22, 2025. For details and the application form, please visit the ISRT admission page:</b>
    </a>
        </div>
    </div>

    <style>
        .custom-marquee {
            width: 100%;
            overflow: hidden;
            white-space: nowrap;
            background: #e6e6e6;
            padding: 8px 0;
            position: relative;
            margin-top: 35px;
            height: 35px;
        }

        .marquee-content {
            display: inline-block;
            position: absolute;
            white-space: nowrap;
            will-change: transform;
            animation: scroll-left 30s linear infinite;
            font-weight: bold;
            font-size: 16px;
        }

        .custom-marquee:hover .marquee-content {
            animation-play-state: paused;
        }

        @keyframes scroll-left {
            0% {
                transform: translateX(100%);
            }
            100% {
                transform: translateX(-100%);
            }
        }
    </style>
    <!-- /end HFCM by 99 Robots -->
    <meta name="tec-api-version" content="v1">
    <meta name="tec-api-origin" content="https://isrt.ac.bd">
    <link rel="alternate" href="https://isrt.ac.bd/wp-json/tribe/events/v1/" />
    <link rel="icon" href="https://isrt.ac.bd/wp-content/uploads/2017/04/du-logo-26px.png" sizes="32x32" />
    <link rel="icon" href="https://isrt.ac.bd/wp-content/uploads/2017/04/du-logo-26px.png" sizes="192x192" />
    <link rel="apple-touch-icon" href="https://isrt.ac.bd/wp-content/uploads/2017/04/du-logo-26px.png" />
    <meta name="msapplication-TileImage" content="https://isrt.ac.bd/wp-content/uploads/2017/04/du-logo-26px.png" />
    <style type="text/css" id="wp-custom-css">
        /*
You can add your own CSS here.

Click the help icon above to learn more.
*/

        .tribe-events-list-widget .tribe-list-widget,
        .tribe-events-list-widget .tribe-events-list-widget-events {
            padding: 0
        }

        aside#block-2 {
            margin-bottom: 0;
            border: 0
        }

        #custom_html-5 p img {
            float: left;
            margin-right: 20px;
            margin-bottom: 20px
        }

        #custom_html-5 p {
            clear: both;
            margin-bottom: 20px
        }

        .menu-item {
            display: inline-block
        }

        .navbar-nav {
            display: block;
        }

        #navbarNavDropdown {
            z-index: 888 !important
        }
    </style>
    <style type="text/css">
        /** Mega Menu CSS: fs **/
    </style>
